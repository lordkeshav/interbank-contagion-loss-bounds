"""Certify jointly feasible loss extrema on two-debtor disclosure blocks."""

import argparse
from itertools import combinations, permutations, product
import json
from pathlib import Path

import numpy as np
import pandas as pd

from study import SHOCK_TYPES, amplification, clearing, make_network, upper_envelope


SEED = 124031
NETWORKS_PER_GROUP = 24
ROUNDING_BP = 1e-7
GEOMETRY_TOL = 1e-9


def tighten(lower, upper, row):
    if lower.sum() > row + 1e-11 or upper.sum() < row - 1e-11:
        return None
    lo = np.maximum(lower, row - (upper.sum() - upper))
    hi = np.minimum(upper, row - (lower.sum() - lower))
    if np.any(lo - hi > 1e-11):
        return None
    return np.minimum(lo, hi), hi


def select_block(net, columns, rng):
    order = rng.permutation(len(net.asset))
    for a, b in combinations(order.tolist(), 2):
        choices = [j for j in order if j not in (a, b) and net.liabilities[a, j] + net.liabilities[b, j] > 0]
        for creditors in combinations(choices, columns):
            h = net.liabilities[np.ix_([a, b], creditors)]
            row = h[0].sum()
            col = h.sum(axis=0)
            root = tighten(np.zeros(columns), col, row)
            if h[1].sum() > 0 and root is not None and np.min(root[1]-root[0]) > 1e-7:
                observed = net.liabilities.copy()
                observed[np.ix_([a, b], creditors)] = 0
                return (a, b), np.array(creditors), row, col, observed
    return None


def candidate_allocations(lo, hi, row):
    """Vertices from greedy coordinate orders and one interior allocation."""
    span = hi-lo
    room = max(0.0, row-lo.sum())
    midpoint = lo + span * min(1.0, room/max(span.sum(), 1e-15))
    choices = [midpoint]
    for order in permutations(range(len(lo))):
        value = lo.copy()
        left = room
        for j in order:
            add = min(span[j], left)
            value[j] += add
            left -= add
        choices.append(value)
    points = np.unique(choices, axis=0)
    assert np.max(np.abs(points.sum(axis=1)-row)) < 1e-9
    return points


def point_risks(points, spec):
    sources, creditors, col, observed, d, payable, external = spec
    a, b = sources
    fitted = np.broadcast_to(observed, (len(points), *observed.shape)).copy()
    fitted[:, a, creditors] = points
    fitted[:, b, creditors] = col[None]-points
    for axis in (1, 2):
        assert np.max(np.ptp(fitted.sum(axis=axis), axis=0)) < 2e-9
    assert fitted.min() >= -1e-10
    q, _, residual = clearing(fitted, np.broadcast_to(d, (len(points), 1, len(d))),
                              np.broadcast_to(payable, (len(points), len(d))))
    direct = (d/payable).clip(0, 1)
    rho = np.max(fitted.sum(axis=2)/payable)
    drift = 1e4*sum(payable)*residual/((1-rho)*sum(external))
    assert drift < ROUNDING_BP, drift
    return ((q[:, 0, :]-direct)*external).sum(axis=1)*1e4/external.sum()


def relaxed_shortfalls(lo, hi, spec, direction):
    """Bound any feasible allocation by optimising incoming columns separately."""
    sources, creditors, col, observed, d, payable, external = spec
    a, b = sources
    direct = (d/payable).clip(0, 1)
    back = np.ones_like(d) if direction == 1 else direct.copy()
    for _ in range(160):
        gap = back[a]-back[b]
        assignment = hi if direction*gap >= 0 else lo
        loss = d + back @ observed
        loss[creditors] += col*back[b] + assignment*gap
        update = (loss/payable).clip(0, 1)
        assert np.max(direction*(update-back)) < 1e-10
        change = np.max(abs(update-back))
        back = update
        if change < 1e-12:
            break
    return back


def vertices(coeff, intercept):
    """Vertices of coeff @ y + intercept >= 0 in one or two dimensions."""
    lengths = np.linalg.norm(coeff,axis=1)
    normal = lengths > 1e-13
    if np.any(intercept[~normal] < -GEOMETRY_TOL):
        return np.empty((0,coeff.shape[1]))
    coeff = coeff[normal]/lengths[normal,None]
    intercept = intercept[normal]/lengths[normal]
    if coeff.shape[1] == 1:
        coeff = coeff[:,0]
        lower = (-intercept[coeff>0]/coeff[coeff>0]).max()
        upper = (-intercept[coeff<0]/coeff[coeff<0]).min()
        return np.array([[lower],[upper]]) if lower <= upper+GEOMETRY_TOL else np.empty((0,1))
    i,j = np.triu_indices(len(coeff),1)
    left,right = coeff[i],coeff[j]
    det = left[:,0]*right[:,1]-left[:,1]*right[:,0]
    nonparallel = abs(det)>1e-12
    i,j,det = i[nonparallel],j[nonparallel],det[nonparallel]
    points = np.column_stack(((-intercept[i]*coeff[j,1]+intercept[j]*coeff[i,1])/det,
                              (-coeff[i,0]*intercept[j]+coeff[j,0]*intercept[i])/det))
    mask = np.min(points@coeff.T+intercept,axis=1,initial=np.inf) >= -GEOMETRY_TOL
    return points[mask]


def region_vertices(mask, base, transform, center, spec):
    """Active-set inequalities after multiplication by the positive denominator."""
    sources, recipients, col, _, d, payable, _ = spec
    active = np.flatnonzero(mask)
    healthy = np.flatnonzero(~mask)
    k = transform.shape[1]
    a,b = sources
    difference = np.zeros(len(d))
    difference[a],difference[b] = 1,-1
    pivot = np.diag(payable[active])-base[np.ix_(active,active)].T
    solved = np.linalg.solve(pivot,np.column_stack((d[active],transform[active])))
    u = solved[:,0]
    v = solved[:,1:]
    diff0 = difference[active]@u
    den = -(difference[active]@v)
    numer = u[:,None]*den + diff0*v
    cross = base[np.ix_(active,healthy)].T
    inactive0 = d[healthy] + cross@u
    inactive = inactive0[:,None]*den + diff0*(cross@v+transform[healthy])
    coeff = np.vstack((transform[recipients],-transform[recipients],numer,
                       np.broadcast_to(den,(len(active),k))-numer,-inactive))
    intercept = np.r_[center,col-center,u,1-u,-inactive0]
    polys = vertices(coeff,intercept)
    if not len(polys):
        return np.empty((0,len(col)))
    assert np.min(1+polys@den)>0
    points = center+polys@transform[recipients].T
    return points


def extrema(row, col, spec):
    """Enumerate the linear-fractional clearing regions of a small disclosure block."""
    sources, recipients, _, observed, d, payable, external = spec
    lo,hi = tighten(np.zeros_like(col),col,row)
    center = col*(row/col.sum())
    base = observed.copy()
    base[sources[0],recipients] = center
    base[sources[1],recipients] = col-center
    transform = np.zeros((len(d),len(col)-1))
    transform[recipients[:-1]] = np.eye(len(col)-1)
    transform[recipients[-1]] = -1
    inner = relaxed_shortfalls(lo,hi,spec,-1)
    outer = relaxed_shortfalls(lo,hi,spec,1)
    forced = inner>1e-10
    possible = outer>0
    unknown = np.flatnonzero(possible & ~forced)
    found = [candidate_allocations(lo,hi,row)]
    regions = 0
    for state in product((False,True),repeat=len(unknown)):
        mask = forced.copy()
        mask[unknown] = state
        region = region_vertices(mask,base,transform,center,spec)
        if len(region):
            assert np.min(region)>=-2*GEOMETRY_TOL and np.max(region-col)<=2*GEOMETRY_TOL
            found.append(region)
            regions += 1
    assert regions>0
    points = np.unique(np.concatenate(found),axis=0)
    risks = point_risks(points,spec)
    root = ((outer-(d/payable).clip(0,1))*external).sum()*1e4/external.sum()
    return float(risks.min()),float(risks.max()),regions,root


def audit_network(net, block, n, columns, index):
    sources, recipients, row, col, observed = block
    payable, external = net.payable, net.outside
    raw = net.shock*net.asset-net.equity
    direct = (raw/payable).clip(0,1)[None]
    hidden = net.liabilities-observed
    allowed = np.zeros_like(observed,dtype=bool)
    allowed[np.ix_(sources,recipients)] = True
    q_low,_,_ = clearing(observed[None], raw[None], payable[None])
    q_true,_,_ = clearing(net.liabilities[None], raw[None], payable[None])
    q_up = upper_envelope(dict(observed=observed[None], d=raw[None], payable=payable[None],
                               c=hidden.sum(axis=0)[None], r=hidden.sum(axis=1)[None],
                               allowed=allowed[None]))
    target, outer_lower, outer_upper = map(lambda q:amplification(q,direct,external[None])[0],
                                          (q_true,q_low,q_up))
    lo,hi = tighten(np.zeros_like(col),col,row)
    extremes = candidate_allocations(lo,hi,row)
    rng = np.random.default_rng(np.random.SeedSequence([SEED,n,columns,index]))
    checks = rng.dirichlet(np.ones(len(extremes)),size=24)@extremes
    results = []
    for s, d in enumerate(raw):
        spec = sources,recipients,col,observed,d,payable,external
        minimum,maximum,regions,root = extrema(row,col,spec)
        checked = point_risks(checks,spec)
        assert minimum-ROUNDING_BP <= checked.min() and maximum+ROUNDING_BP >= checked.max()
        assert minimum-ROUNDING_BP <= target[s] <= maximum+ROUNDING_BP
        assert minimum >= outer_lower[s]-ROUNDING_BP and maximum <= outer_upper[s]+ROUNDING_BP
        assert abs(root-outer_upper[s]) < 2e-6
        results.append(dict(banks=n, hidden_receivers=columns, network_id=index, scenario_id=s,
                            shock=SHOCK_TYPES[s//3], true_loss=target[s], lower=outer_lower[s], upper=outer_upper[s],
                            minimum_feasible=minimum,maximum_feasible=maximum,active_regions=regions))
    return results


def checks():
    # Four-node example. One debtor alone is in distress. At most one creditor gets
    # a loss above capital, while the columnwise relaxation copies that capacity.
    spec = ((0,1),np.array([2,3]),np.array([10.,10.]),np.zeros((4,4)),
            np.array([32.,0.,-3.,-3.]),np.repeat(80.,4),np.array([70.,70.,80.,80.]))
    lo,hi,_,root = extrema(10,spec[2],spec)
    assert abs(lo)<ROUNDING_BP and abs(hi-10000/300)<ROUNDING_BP
    assert abs(root-20000/300) < 2e-6
    points = np.linspace(0,10,2001)
    values = point_risks(np.column_stack((points,10-points)),spec)
    assert abs(lo-values.min())<ROUNDING_BP and abs(hi-values.max())<ROUNDING_BP


def summarise(df):
    def one(x):
        gap = x.upper-x.maximum_feasible
        lower = x.minimum_feasible-x.lower
        return {
            'networks':len(x[['banks','hidden_receivers','network_id']].drop_duplicates()),
            'scenarios':len(x), 'mean_outer_upper_bp':float(x.upper.mean()),
            'mean_joint_max_bp':float(x.maximum_feasible.mean()),
            'mean_upper_slack_bp':float(gap.mean()),'median_upper_slack_bp':float(gap.median()),
            'p90_upper_slack_bp':float(gap.quantile(.9)), 'max_upper_slack_bp':float(gap.max()),
            'mean_lower_slack_bp':float(lower.mean()),
            'upper_slack_over_1bp_pct':float(100*(gap>1).mean()),
            'min_nonempty_active_regions':int(x.active_regions.min()),
            'max_nonempty_active_regions':int(x.active_regions.max()),
        }
    return {'all':one(df), 'groups':{f'{b} banks, 2×{c}':one(x) for (b,c),x in df.groupby(['banks','hidden_receivers'])}}


def run(output, networks):
    checks()
    rng = np.random.default_rng(SEED)
    rows = []
    for banks in (8,12):
        for receiver_count in (2,3):
            for index in range(networks):
                while True:
                    network = make_network(banks,rng,'modular')
                    block = select_block(network,receiver_count,rng)
                    if block is not None:
                        break
                rows.extend(audit_network(network,block,banks,receiver_count,index))
            print(f'{banks} banks, 2x{receiver_count}: {networks*9} scenarios checked',flush=True)
    df = pd.DataFrame(rows)
    output.mkdir(parents=True,exist_ok=True)
    df.to_csv(output/'bound_audit.csv',index=False)
    summary = summarise(df)
    summary.update(network_seed=SEED,networks_per_group=networks,geometry_tolerance=GEOMETRY_TOL,
                   feasible_check_points_per_scenario=24)
    (output/'bound_audit.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary['all'],indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=Path('extension'))
    parser.add_argument('--networks-per-group',type=int,default=NETWORKS_PER_GROUP)
    args = parser.parse_args()
    run(args.output,args.networks_per_group)
