"""Revised disclosure experiments, paired comparisons and calibrated sensitivity."""

import argparse
from copy import deepcopy
import json
import os
import platform
from pathlib import Path
from time import perf_counter

os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

from reconstruction_extension import (
    CALIBRATION_COUNT, CALIBRATION_NAME, CALIBRATION_SEED, DRAW_COUNT,
    NAME as SPARSE, calibrated_network, fit_support, load_models, sparse_predict,
    topology_stats,
)
from study import (
    CONFIG, EPS, FIT_SEEDS, MATCHED, METHODS, SHOCK_TYPES, amplification, clearing,
    conservation_upper, features, fit, gradient_check, intervals, make_network,
    neural_prior, scale_prior, take, train_views, upper_envelope,
)

OBSERVED, FLAT, PAIRWISE, MLP, GNN = METHODS
POINT_METHODS = (FLAT, PAIRWISE, MLP, MATCHED, GNN)
ALL_METHODS = (OBSERVED, *POINT_METHODS, SPARSE)
THRESHOLDS_BP = (10, 25, 50)
LARGEST_UNKNOWN = 'Largest-first 50%, rule unknown'
LARGEST_KNOWN = 'Largest-first 50%, cutoff known'
FACTOR_SEED = 661407
TURKIYE_SEED = 846301
TURKIYE_BANKS = 48
TURKIYE_DENSITY = .181
TURKIYE_SHARES = (.009, .020, .031)
FACTOR_SHARES = (.0264, .2222)
FACTOR_DENSITIES = (.055, .174)
FACTOR_DISCLOSURES = (.25, .75)
CONDITIONS = (
    ('Modular 25%', 'test_modular', .25, 'Uniform', False),
    ('Modular 50%', 'test_modular', .50, 'Uniform', False),
    ('Modular 75%', 'test_modular', .75, 'Uniform', False),
    (LARGEST_UNKNOWN, 'test_modular', .50, 'Large-first', False),
    (LARGEST_KNOWN, 'test_modular', .50, 'Large-first', True),
    ('Core-periphery 50%', 'test_core', .50, 'Uniform', False),
    ('48-bank 50%', 'test_size', .50, 'Uniform', False),
)


def generated_groups(config):
    names = ('train', 'validation', 'test_modular', 'test_core', 'test_size')
    streams = np.random.SeedSequence(config['network_seed']).spawn(len(names))
    result = {}
    for name, stream in zip(names, streams):
        n = config['size_shift_banks'] if name == 'test_size' else config['banks']
        topology = 'core' if name == 'test_core' else 'modular'
        result[name] = [make_network(n, np.random.default_rng(seed), topology)
                        for seed in stream.spawn(config[name])]
    return result


def fit_matched(groups, config, destination):
    started = perf_counter()
    train, valid = (train_views(groups[key]) for key in ('train', 'validation'))
    check = gradient_check(take(train, slice(0,4)), kinds=(MATCHED,))
    fitted = [fit(MATCHED, seed, train, valid, config) for seed in FIT_SEEDS]
    models, histories = zip(*fitted)
    assert all(item['parameters'] == 4101 for item in histories)
    np.savez_compressed(destination/'matched_weights.npz',
                        **{f'{i}_{key}': value for i, p in enumerate(models)
                           for key, value in p.items()})
    return list(models), dict(fits=histories, gradient_check_max_abs=check,
                              seconds=perf_counter()-started)


def load_matched(path):
    with np.load(path) as saved:
        return [{key[2:]: saved[key] for key in saved.files if key.startswith(f'{i}_')}
                for i in range(len(FIT_SEEDS))]


def prepare(nets, coverage, mechanism, known):
    data = features(nets, coverage, mechanism)
    if mechanism == 'Large-first':
        observed = data['observed']
        cutoff = np.where(observed > 0, observed, np.inf).min(axis=(1,2))
        assert np.max(data['hidden']-cutoff[:,None,None]) < 1e-10
        if known:
            data['cutoff'] = cutoff
    return data


def bounded_clearing(data):
    q0 = (data['d']/data['payable'][:,None]).clip(0,1)
    low_q, _, _ = clearing(data['observed'], data['d'], data['payable'])
    keys = tuple(key for key in ('d', 'payable', 'observed', 'c', 'r', 'allowed', 'cutoff')
                 if key in data)
    top_q = np.concatenate([
        upper_envelope({key: data[key][i:i+24] for key in keys})
        for i in range(0,len(q0),24)])
    lower = amplification(low_q, q0, data['external'])
    column = amplification(top_q, q0, data['external'])
    cap = conservation_upper(data, low_q)
    return q0, lower, column, cap, np.minimum(column, cap)


def allocate(method, models, data, diagnostics):
    if method == FLAT:
        logits = np.zeros_like(data['observed'])
    else:
        logits = np.mean([neural_prior(weights,data,method)[0] for weights in models[method]],axis=0)
    hidden, margin = scale_prior(logits, data, diagnostics)
    return data['observed'] + hidden, margin


def screening(lower, upper, truth):
    by_threshold = {}
    for t in THRESHOLDS_BP:
        below = upper <= t
        above = lower > t
        assert not np.any(below & (truth > t+1e-7))
        assert not np.any(above & (truth < t-1e-7))
        by_threshold[str(t)] = {
            'at_or_below': int(below.sum()), 'above': int(above.sum()),
            'needs_disclosure': int((~(below|above)).sum()), 'cases': len(truth.ravel()),
        }
    return by_threshold


def main_metrics(risk, truth, event, score, fit_matrix, data, include_exposure=True):
    error = risk - truth
    out = dict(mae=float(abs(error).mean()), bias=float(error.mean()),
               p90=float(np.quantile(abs(error),.90)),
               ap=float(average_precision_score(event,score)) if np.any(event) else None)
    if include_exposure:
        moved = abs(fit_matrix-data['full']).sum(axis=(1,2))
        out['realloc_pct'] = float(50*np.mean(moved/np.maximum(data['hidden'].sum(axis=(1,2)),EPS)))
    return out


def condition(name, nets, coverage, mechanism, known, models, support, seed, support_stream=None):
    data = prepare(nets,coverage,mechanism,known)
    real_q, _, _ = clearing(data['full'],data['d'],data['payable'])
    q0, lower, column, cap, upper = bounded_clearing(data)
    truth = amplification(real_q,q0,data['external'])
    assert np.max(lower-truth)<1e-7 and np.max(truth-upper)<1e-7
    candidate = data['d']<=0
    events = real_q[candidate]>CONFIG['event_tolerance']
    n = len(nets)
    rng = np.random.default_rng(seed)
    sparse_rng = rng if support_stream is None else support_stream
    observed = data['observed']
    if mechanism=='Large-first':
        rule_limit = np.where(observed>0,observed,np.inf).min(axis=(1,2))
    else:
        rule_limit = None
    losses = {}
    metrics = {}
    for method in (OBSERVED,*POINT_METHODS):
        started = perf_counter()
        diagnostics = {}
        if method == OBSERVED:
            matrix, margin = observed, None
        else:
            matrix, margin = allocate(method,models,data,diagnostics)
        short, score, residual = clearing(matrix,data['d'],data['payable'])
        elapsed = (perf_counter()-started)*1000/n
        estimate = amplification(short,q0,data['external'])
        losses[method] = estimate
        entry = main_metrics(estimate,truth,events,score[candidate],matrix,data,method!=OBSERVED)
        entry.update(projection=diagnostics,elapsed_ms_per_network=elapsed,margin_residual=margin,
                     clearing_residual=residual)
        if rule_limit is not None:
            ratio = (matrix-observed)/rule_limit[:,None,None]
            violations = ratio>1+1e-7
            entry.update(cutoff_networks=int(violations.any(axis=(1,2)).sum()),
                         cutoff_edges=int(violations.sum()),cutoff_ratio_max=float(ratio.max()))
            if known:
                assert not violations.any(), (method, name)
        metrics[method] = entry
    value_logits = neural_prior(models[PAIRWISE][0],data,PAIRWISE)[0]
    sparse, pred, target = sparse_predict(data,support,value_logits,sparse_rng,DRAW_COUNT)
    assert np.max(abs(target-truth))<1e-8
    if known:
        assert sparse['max_cutoff_excess']<1e-7
    losses[SPARSE],metrics[SPARSE] = pred,sparse
    for method, estimate in losses.items():
        if method != OBSERVED:
            assert np.max(lower-estimate)<1e-7 and np.max(estimate-upper)<1e-7, (name,method)
    gnn_error = abs(losses[GNN]-truth)
    deltas = {}
    for method in (SPARSE,MLP,FLAT,PAIRWISE,MATCHED):
        contrast = (gnn_error-abs(losses[method]-truth)).mean(axis=1)
        bootstrap_rng = sparse_rng if method in (SPARSE,MLP) else rng
        deltas[method] = dict(mean=float(contrast.mean()), ci=intervals(contrast,bootstrap_rng,CONFIG['bootstrap_draws']))
    summary = dict(networks=n,banks=len(nets[0].asset),coverage=coverage,mechanism=mechanism,
                   cutoff_known=known,scenarios=int(truth.size),true_loss_mean=float(truth.mean()),
                   indirect_prevalence=float(events.mean()),bounds_width=float((upper-lower).mean()),
                   column_width=float((column-lower).mean()),
                   p90_width=float(np.quantile(upper-lower,.9)), p90_column_width=float(np.quantile(column-lower,.9)),
                   width_improved_cases=int(np.sum(column-upper>1e-6)),
                   disclosure_value_pct=float(100*np.mean(observed.sum(axis=(1,2))/data['full'].sum(axis=(1,2)))),
                   true_topology=topology_stats(data['full']),
                   exposure_assets_pct=float(100*np.mean(data['full'].sum(axis=(1,2))/
                                      (data['asset'].sum(axis=1)+data['full'].sum(axis=(1,2))))),
                   models=metrics,gnn_differences=deltas,screening=screening(lower,upper,truth),
                   column_screening=screening(lower,column,truth))
    rows = []
    for method, estimate in losses.items():
        z = pd.DataFrame(dict(condition=name, method=method,
                              network_id=np.repeat(np.arange(n), truth.shape[1]),
                              scenario_id=np.tile(np.arange(truth.shape[1]),n),
                              shock=np.tile(np.repeat(SHOCK_TYPES,3),n),
                              true_bps=truth.ravel(), predicted_bps=estimate.ravel(),
                              lower_bps=lower.ravel(), column_bps=column.ravel(),
                              conservation_bps=cap.ravel(), upper_bps=upper.ravel()))
        rows.append(z)
    print(f"{name} | {n} networks | mean width {summary['bounds_width']:.2f} bp | "
          f"MAE GNN {metrics[GNN]['mae']:.3f}, matched MLP {metrics[MATCHED]['mae']:.3f}, "
          f"reciprocal {metrics[SPARSE]['mae']:.3f}",flush=True)
    return summary, pd.concat(rows,ignore_index=True)


def save_run(destination, metadata, sets, records):
    metadata['conditions'] = sets
    (destination/'summary.json').write_text(json.dumps(metadata,indent=2,allow_nan=False)+'\n')
    pd.concat(records,ignore_index=True).to_csv(
        destination/'scenarios.csv.gz',index=False,compression={'method':'gzip','mtime':0})


def run_comparison(root, output, name):
    source = root/name
    destination = output/name
    destination.mkdir(parents=True,exist_ok=True)
    config = json.loads((source/'summary.json').read_text())['config']
    groups = generated_groups(config)
    weights = load_models(source)
    weights[MATCHED], fitted = fit_matched(groups,config,destination)
    support, support_fit = fit_support(groups['train'])
    np.save(destination/'reciprocal_parameters.npy',support)
    results, records = {}, []
    support_stream = np.random.default_rng(616131+(name=='replication'))
    for i,(label, group, frac, mechanism, known) in enumerate(CONDITIONS):
        shared_mask_seed = 3 if known else i
        seed = config['network_seed']+76001+shared_mask_seed
        if label == LARGEST_UNKNOWN:
            paired_support_stream = deepcopy(support_stream)
        draws = paired_support_stream if known else support_stream
        results[label], frame = condition(label,groups[group],frac,mechanism,known,weights,support,seed,draws)
        records.append(frame)
    save_run(destination,dict(config=config,matched_fit=fitted,reciprocal_fit=support_fit,
                             reciprocal_rng_state=support_stream.bit_generator.state,
                             runtime_environment=dict(platform=platform.platform(),python=platform.python_version(),
                                    cpu_count=os.cpu_count(),blas_threads=os.getenv('OPENBLAS_NUM_THREADS'))),
             results,records)


def calibration_cases():
    mixed_seeds = np.random.SeedSequence(CALIBRATION_SEED).spawn(CALIBRATION_COUNT)
    mixed = [calibrated_network(np.random.default_rng(s)) for s in mixed_seeds]
    yield CALIBRATION_NAME,mixed,.50,610201
    paired = np.random.SeedSequence(FACTOR_SEED).spawn(48)
    for density in FACTOR_DENSITIES:
        for share in FACTOR_SHARES:
            networks = [calibrated_network(np.random.default_rng(s),density=density,exposure_share=share)
                        for s in paired]
            for coverage in FACTOR_DISCLOSURES:
                label = f'Factor {100*density:.1f}% density, {100*share:.2f}% exposures, {100*coverage:.0f}% disclosed'
                yield label,networks,coverage,FACTOR_SEED+int(100*coverage)
    turkiye = np.random.SeedSequence(TURKIYE_SEED).spawn(64)
    for share in TURKIYE_SHARES:
        networks = [calibrated_network(np.random.default_rng(s),n=TURKIYE_BANKS,
                                       density=TURKIYE_DENSITY,reciprocity=None,exposure_share=share)
                    for s in turkiye]
        yield f'Türkiye {100*share:.2f}% exposures',networks,.50,TURKIYE_SEED


def run_validation(root, output):
    destination=output/'validation'
    destination.mkdir(parents=True,exist_ok=True)
    weights=load_models(root/'results')
    weights[MATCHED]=load_matched(output/'results'/'matched_weights.npz')
    support=np.load(output/'results'/'reciprocal_parameters.npy')
    support_stream=np.random.default_rng()
    primary=json.loads((output/'results'/'summary.json').read_text())
    support_stream.bit_generator.state=primary['reciprocal_rng_state']
    results,records={},[]
    for label,networks,fraction,seed in calibration_cases():
        draws=support_stream if label==CALIBRATION_NAME else None
        results[label],frame=condition(label,networks,fraction,'Uniform',False,weights,support,seed,draws)
        records.append(frame)
    save_run(destination,dict(factor_seed=FACTOR_SEED,turkiye_seed=TURKIYE_SEED,
                              cross_market_seed=CALIBRATION_SEED),results,records)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path('.'))
    parser.add_argument('--output',type=Path,default=Path('review_results'))
    parser.add_argument('--stage',choices=('all','results','replication','validation'),default='all')
    args=parser.parse_args()
    for run_name in ('results','replication','validation'):
        if args.stage not in ('all',run_name):
            continue
        if run_name == 'validation':
            run_validation(args.root,args.output)
        else:
            run_comparison(args.root,args.output,run_name)
