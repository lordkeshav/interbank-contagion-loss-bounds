"""Produce the manuscript figures from the configured simulation outputs."""

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch, Rectangle


INK = '#182637'
MUTED = '#516176'
TEAL = '#176A81'
RED = '#A44231'
GOLD = '#A36F17'
PLUM = '#665487'
GRID = '#DFE5EB'
PAL = {
    'Flat RAS': (MUTED, 's', '--'), 'Pairwise RAS': (GOLD, 'D', '-.'),
    'No-message MLP': (PLUM, '^', ':'), 'Reciprocal sparse': ('#426D44', 'v', '-.'),
    'Matched MLP': ('#963B68', 'P', '--'), 'GNN-RAS': (TEAL, 'o', '-'),
}
WIDTH = 6.22

plt.rcParams.update({
    'font.family': 'Liberation Sans', 'font.size': 8.5, 'axes.labelsize': 9,
    'xtick.labelsize': 8.5, 'ytick.labelsize': 8.5, 'legend.fontsize': 8.2,
    'text.color': INK, 'axes.labelcolor': INK, 'axes.edgecolor': MUTED,
    'axes.linewidth': .65, 'xtick.color': INK, 'ytick.color': INK,
    'ps.fonttype': 42, 'pdf.fonttype': 42, 'svg.fonttype': 'none',
})


def commit(fig, filename):
    fig.savefig(filename.with_suffix('.png'), dpi=600, facecolor='white')
    fig.savefig(filename.with_suffix('.eps'), facecolor='white')
    plt.close(fig)


def arrow(ax, a, b, shade=MUTED, line=1.0, dashed=False):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle='-|>', mutation_scale=8.0,
                 linewidth=line, linestyle='--' if dashed else '-', color=shade, shrinkA=0, shrinkB=0))


def box(ax, x, y, width, height, fill, edge=GRID):
    patch = FancyBboxPatch((x,y), width, height, boxstyle='round,pad=0.12,rounding_size=0.8',
                           facecolor=fill, edgecolor=edge, linewidth=.68)
    ax.add_patch(patch)
    return patch


def architecture(out):
    fig, ax = plt.subplots(figsize=(WIDTH, 2.10))
    fig.subplots_adjust(left=.012, right=.988, bottom=.018, top=.982)
    ax.set(xlim=(0,100), ylim=(0,34))
    ax.axis('off')
    blocks = [(0.4,22.9,'(a) Disclosure','Reported links\nand balance sheets'),
              (26.0,22.9,'(b) Directed GNN','Incoming and\noutgoing messages'),
              (51.6,22.9,'(c) Matrix scaling','Reconcile missing\nexposure totals'),
              (77.2,22.4,'(d) Stress test','Clearing estimate\nand feasible bounds')]
    for x,w,label,footer in blocks:
        box(ax,x,.7,w,32.6,'#F7FAFC')
        ax.text(x+w/2,29.45,label,ha='center',va='center',weight='bold',fontsize=9.2)
        ax.text(x+w/2,5.05,footer,ha='center',va='center',fontsize=8.6,linespacing=1.19)
    for x in [23.5,49.1,74.7]:
        arrow(ax,(x,16.7),(x+2.2,16.7),line=.87)
    nodes = [(5.6,21.0),(17.3,21.5),(6.4,12.4),(17.3,12.4),(11.5,17.0)]
    for p,q,col,ls in [(0,4,TEAL,False),(4,1,TEAL,False),(4,3,TEAL,False),
                       (2,4,MUTED,True),(3,1,MUTED,True)]:
        v = np.subtract(nodes[q],nodes[p]); u = v/np.linalg.norm(v)
        arrow(ax,np.add(nodes[p],1.5*u),np.subtract(nodes[q],1.5*u),col,.9,ls)
    for i,(x,y) in enumerate(nodes):
        ax.add_patch(Circle((x,y),1.48,facecolor='#E4F2F5' if i==4 else 'white',edgecolor=TEAL,linewidth=.9))
    ax.text(11.5,17.0,'i',ha='center',va='center',fontsize=8.6,weight='bold')
    for x,y,lab,col in [(30.7,20.4,'j',TEAL),(30.7,13.4,'k',TEAL),(44.2,17.0,'m',GOLD)]:
        ax.add_patch(Circle((x,y),1.6,facecolor='white',edgecolor=col,linewidth=.9))
        ax.text(x,y,lab,ha='center',va='center',fontsize=8.6)
    ax.add_patch(Circle((37.3,17.0),1.83,facecolor='#E4F2F5',edgecolor=TEAL,linewidth=1.1))
    ax.text(37.3,17,'i',ha='center',va='center',fontsize=9,weight='bold')
    arrow(ax,(32.2,19.6),(35.5,17.9),TEAL)
    arrow(ax,(32.2,14.1),(35.5,16.1),TEAL)
    arrow(ax,(39.2,17),(42.5,17),GOLD)
    ax.text(37.7,23.85,'Weighted by exposure',ha='center',fontsize=8.1,color=MUTED)
    sem = [[0,2,1],[2,0,2],[1,2,0]]
    for row in range(3):
        for col in range(3):
            x,y = 56.3+3.38*col,20.2-3.38*row
            ax.add_patch(Rectangle((x,y),3.17,3.17,facecolor=['#E7EBF0','#79A9B8','#EBD5A5'][sem[row][col]],
                                   edgecolor='white',linewidth=.65))
        ax.add_patch(Rectangle((67.1,20.2-3.38*row),2.75,3.17,facecolor='#D4DFE7',edgecolor='white',linewidth=.55))
    for col in range(3):
        ax.add_patch(Rectangle((56.3+3.38*col,10.1),3.17,2.7,facecolor='#D4DFE7',edgecolor='white',linewidth=.55))
    arrow(ax,(81.7,11.3),(81.7,23.8),MUTED,.65)
    arrow(ax,(81.7,11.3),(95.7,11.3),MUTED,.65)
    xs=np.array([82.4,85.7,89.2,92.0,95.0]); top=np.array([13,16.4,20.1,21.0,22])
    bottom=np.array([12.3,13.5,15.0,15.3,15.6]); mid=np.array([12.6,14.5,17.0,17.6,18.1])
    ax.fill_between(xs,bottom,top,color='#DCEBF1')
    ax.plot(xs,top,':',color=MUTED,lw=.85)
    ax.plot(xs,bottom,'--',color=MUTED,lw=.85)
    ax.plot(xs,mid,'o-',color=TEAL,lw=1.1,ms=2.8)
    commit(fig,out/'Fig1_architecture')


def workflow(out, data):
    cfg=data['config']
    fig,ax=plt.subplots(figsize=(WIDTH,2.54))
    fig.subplots_adjust(left=.013,right=.987,bottom=.016,top=.984)
    ax.set(xlim=(0,100),ylim=(0,37))
    ax.axis('off')

    def card(x,y,w,h,lines,fill='#F7FAFC'):
        box(ax,x,y,w,h,fill)
        ax.text(x+w/2,y+h-1.40,lines[0],ha='center',va='top',weight='bold',fontsize=8.95)
        if len(lines)>1:
            ax.text(x+w/2,y+h-3.45,'\n'.join(lines[1:]),ha='center',va='top',fontsize=8.55,linespacing=1.15)

    card(30,28.5,40,7.25,('Synthetic banking networks','Assign each network to one split'),'#E5F0F5')
    centers=[16.9,50,83.1]
    ax.plot([16.9,83.1],[25.6,25.6],color=MUTED,lw=.8)
    ax.plot([50,50],[28.45,25.6],color=MUTED,lw=.8)
    for xx in centers:
        arrow(ax,(xx,25.6),(xx,22.8),line=.76)
    tests=cfg['test_modular']+cfg['test_core']+cfg['test_size']
    card(.8,14.0,32.2,8.6,(f'Train  |  {cfg["train"]} networks','Mask bilateral exposures','Fit shared edge scores'))
    card(33.9,14.0,32.2,8.6,(f'Validate  |  {cfg["validation"]} networks','Select training epoch','Use hidden-exposure loss'))
    card(67.0,14.0,32.2,8.6,(f'Test  |  {tests} networks','Freeze model weights','Vary disclosure and topology'))
    arrow(ax,(83.1,13.9),(83.1,11.45),line=.80)
    card(49.7,.85,49.5,10.4,('Held-out clearing comparison','Compare known and unknown cutoffs','Resample networks for paired intervals'),'#E5F0F5')
    ax.text(24.7,6.2,'Each network remains\nin a single split',ha='center',va='center',fontsize=8.8,color=MUTED)
    commit(fig,out/'Fig2_protocol')


def style_axis(ax, axis='y'):
    ax.grid(axis=axis,color=GRID,lw=.65)
    ax.set_axisbelow(True)
    ax.spines[['top','right']].set_visible(False)
    ax.tick_params(length=3.1,width=.65)


def curves(out, data):
    conditions=data['conditions']
    names=['Modular 25%','Modular 50%','Modular 75%']
    fig,axs=plt.subplots(1,2,figsize=(WIDTH,2.53))
    fig.subplots_adjust(left=.094,right=.981,bottom=.345,top=.87,wspace=.32)
    x=[25,50,75]
    for method,(color,marker,line) in PAL.items():
        if method not in conditions[names[0]]['models']:
            continue
        for ax,metric in zip(axs,('mae','ap')):
            values=[conditions[n]['models'][method][metric] for n in names]
            ax.plot(x,values,marker=marker,ls=line,color=color,ms=4.0,lw=1.23,
                    markeredgewidth=.6,label=method)
    for ax,letter in zip(axs,['(a)','(b)']):
        style_axis(ax)
        ax.set(xticks=x,xlim=(21,79),xlabel='Disclosed positive links (%)')
        ax.text(.00,1.045,letter,transform=ax.transAxes,va='bottom',ha='left',weight='bold')
    axs[0].set_ylabel('External loss MAE (bp)')
    axs[1].set_ylabel('Indirect-default average precision')
    handles,legend=axs[0].get_legend_handles_labels()
    fig.legend(handles,legend,loc='lower center',bbox_to_anchor=(.52,.005),ncol=3,frameon=False,
               columnspacing=1.0,handlelength=2.3,handletextpad=.54)
    commit(fig,out/'Fig3_disclosure')


def shifts(out, data, replication):
    rows=data['conditions']
    repeat=replication['conditions']
    labels=['Modular 25%', 'Modular 50%', 'Modular 75%', 'Largest, unknown',
            'Largest, cutoff', 'Core–periphery', '48 banks']
    methods=['Flat RAS','No-message MLP','Matched MLP','Reciprocal sparse']
    fig,axs=plt.subplots(2,2,figsize=(WIDTH,5.10))
    fig.subplots_adjust(left=.208,right=.978,top=.924,bottom=.162,wspace=.22,hspace=.46)
    y=np.arange(len(rows))[::-1]
    for k,(ax,method) in enumerate(zip(axs.flat,methods)):
        ax.set_title(f'({chr(97+k)})  {method}',fontsize=9,loc='left',weight='bold',pad=6)
        ax.axvline(0,color=RED,ls='--',lw=.7)
        for block,shift,color,marker in [(rows,.15,TEAL,'o'),(repeat,-.15,MUTED,'s')]:
            for pos,value in zip(y,block.values()):
                item=value['gnn_differences'][method]
                m=item['mean']
                lo,hi=item['ci']
                ax.errorbar(m,pos+shift,xerr=[[m-lo],[hi-m]],marker=marker,
                            color=color,ms=3.05,capsize=2.,lw=.8)
        ax.set(yticks=y,ylim=(-.62,len(y)-.38))
        ax.set_yticklabels(labels if k%2==0 else ['']*len(labels),fontsize=7.65)
        ax.tick_params(axis='y',length=0,pad=4)
        style_axis(ax,'x')
    fig.supxlabel('Paired MAE difference (bp), GNN-RAS minus comparator',y=.075,fontsize=9)
    from matplotlib.lines import Line2D
    handles=[Line2D([0],[0],color=color,marker=marker,ms=4,lw=1)
                 for color,marker in [(TEAL,'o'),(MUTED,'s')]]
    fig.legend(handles,['Primary','Replication'],loc='lower center',bbox_to_anchor=(.54,.002),
               ncols=2,frameon=False,handlelength=1.65)
    commit(fig,out/'Fig4_paired_error')


def envelope(out,data,case):
    rows=data['conditions']
    names=['Modular 25%','Modular 50%','Modular 75%',
           'Largest-first 50%, rule unknown','Largest-first 50%, cutoff known']
    fig,axs=plt.subplots(1,2,figsize=(WIDTH,2.74),gridspec_kw={'width_ratios':[1.12,1]})
    fig.subplots_adjust(left=.101,right=.978,bottom=.315,top=.865,wspace=.42)
    x=np.arange(len(names))
    ax=axs[0]
    base=[rows[n]['column_width'] for n in names]
    combined=[rows[n]['bounds_width'] for n in names]
    ax.bar(x-.175,base,width=.33,color='#A6B8C6',label='Column only')
    ax.bar(x+.175,combined,width=.33,color=TEAL,label='Combined')
    ax.set(xticks=x,xticklabels=['25','50','75','50\nunknown','50\ncutoff'],
           xlabel='Links disclosed (%)',ylabel='Mean interval width (bp)',ylim=(0,max(base)*1.19))
    ax.tick_params(axis='x',labelsize=7.6)
    style_axis(ax)
    axs[0].text(.00,1.045,'(a)',transform=axs[0].transAxes,ha='left',va='bottom',weight='bold')
    ax=axs[1]
    order=np.argsort(case['sector'],kind='stable')
    x=np.arange(1,len(order)+1)
    lower,upper=100*case['lower'][order],100*case['upper'][order]
    ax.fill_between(x,lower,upper,color='#DDEBF0',step='mid',label='Bank-level bounds')
    ax.plot(x,100*case['true_q'][order],color=INK,lw=.9,marker='o',markersize=2.3,label='Full network')
    ax.plot(x,100*case['predicted_q'][order],color=RED,lw=.95,ls='--',marker='s',markersize=2.0,label='GNN-RAS')
    ax.set(xlim=(.5,len(order)+.5),xticks=[1,8,16,24,32],xlabel='Banks in sector order',ylabel='Payment shortfall (%)')
    style_axis(ax)
    ax.text(.00,1.045,'(b)',transform=ax.transAxes,ha='left',va='bottom',weight='bold')
    hs,ls=axs[0].get_legend_handles_labels()
    hb,lb=axs[1].get_legend_handles_labels()
    fig.legend(hs+hb,ls+lb,loc='lower center',bbox_to_anchor=(.52,.001),frameon=False,ncol=5,
               fontsize=7.6,handlelength=1.4,columnspacing=.8,handletextpad=.38)
    commit(fig,out/'Fig5_bounds')


def joint_bounds(out,audit):
    old=(audit.upper-audit.maximum_feasible).to_numpy()
    new=(audit.tight_upper-audit.maximum_feasible).to_numpy()
    worst=audit.iloc[int(np.argmax(old))]
    fig,axs=plt.subplots(1,2,figsize=(WIDTH,2.60),gridspec_kw={'width_ratios':[1.12,1]})
    fig.subplots_adjust(left=.094,right=.985,bottom=.276,top=.88,wspace=.71)
    xs=np.geomspace(.01,100,450)
    ax=axs[0]
    for values,color,style,name in [(old,MUTED,'--','Column only'),(new,TEAL,'-','Combined')]:
        ax.semilogx(xs,100*(values[:,None]>xs).mean(axis=0),color=color,lw=1.3,ls=style,label=name)
    ax.axvline(1,color=RED,ls=':',lw=.8)
    ax.set(xlim=(.01,100),ylim=(0,10),xticks=(.01,.1,1,10,100),
           xticklabels=('0.01','0.1','1','10','100'),xlabel='Upper gap threshold (bp)',
           ylabel='Cases above threshold (%)')
    style_axis(ax)
    ax.legend(loc='lower left',bbox_to_anchor=(.02,-.61),ncol=2,frameon=False,
              columnspacing=.85,handlelength=1.6,fontsize=8.)
    ax=axs[1]
    intervals=[(worst.lower,worst.upper,MUTED,'s'),
               (worst.lower,worst.tight_upper,TEAL,'s'),
               (worst.minimum_feasible,worst.maximum_feasible,GOLD,'o')]
    for pos,(low,high,color,marker) in zip((2,1,0),intervals):
        ax.hlines(pos,low,high,color=color,linewidth=2.)
        ax.scatter([low,high],[pos,pos],color=color,marker=marker,s=17,zorder=3)
    ax.set(xlim=(74,321),ylim=(-.48,2.48),xticks=(100,150,200,250,300),yticks=(2,1,0),
           yticklabels=('Column only','Combined','Attainable'),xlabel='Incremental loss (bp)')
    ax.tick_params(axis='y',length=0,pad=4,labelsize=8.1)
    style_axis(ax,'x')
    for ax,label in zip(axs,('(a)','(b)')):
        ax.text(0,1.05,label,transform=ax.transAxes,ha='left',va='bottom',weight='bold')
    commit(fig,out/'Fig6_joint_bounds')


def calibration_plot(out,val):
    fig,axs=plt.subplots(2,2,figsize=(WIDTH,4.15))
    fig.subplots_adjust(left=.116,right=.978,top=.89,bottom=.175,wspace=.38,hspace=.51)
    for row,share in enumerate((2.64,22.22)):
        for col,(metric,title) in enumerate((('width','Mean interval width (bp)'),
                                             ('screen','Cases needing disclosure (%)'))):
            ax=axs[row,col]
            ax.set_title(f'({chr(97+2*row+col)})  {share:.2f}% exposures / assets',
                         loc='left',fontsize=9,weight='bold',pad=6)
            for density,color,marker,line in [(5.5,TEAL,'o','-'),(17.4,PLUM,'D','--')]:
                values=[]
                for coverage in (25,75):
                    name=f'Factor {density:.1f}% density, {share:.2f}% exposures, {coverage}% disclosed'
                    entry=val['conditions'][name]
                    decision=entry['screening']['25']
                    values.append(entry['bounds_width'] if metric=='width'
                                  else 100*decision['needs_disclosure']/decision['cases'])
                ax.plot([25,75],values,marker=marker,lw=1.2,color=color,ls=line,ms=4,
                        label=f'{density:.1f}% density')
            ax.set(xlim=(20,80),xticks=[25,75],ylabel=title)
            if row==1:
                ax.set_xlabel('Links disclosed (%)')
            ylo,yhi=ax.get_ylim()
            ax.set_ylim(min(0.,ylo),max(1.,yhi))
            style_axis(ax)
    handles,names=axs[0,0].get_legend_handles_labels()
    fig.legend(handles,names,loc='lower center',bbox_to_anchor=(.54,.002),ncols=2,frameon=False)
    commit(fig,out/'Fig7_calibration')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results',type=Path,default=Path('results'))
    parser.add_argument('--review',type=Path,default=Path('review_results'))
    parser.add_argument('--output',type=Path,default=Path('figures'))
    a=parser.parse_args()
    a.output.mkdir(exist_ok=True,parents=True)
    data=json.loads((a.review/'results'/'summary.json').read_text())
    replic=json.loads((a.review/'replication'/'summary.json').read_text())
    val=json.loads((a.review/'validation'/'summary.json').read_text())
    case=np.load(a.results/'case.npz')
    architecture(a.output)
    workflow(a.output,data)
    curves(a.output,data)
    shifts(a.output,data,replic)
    envelope(a.output,data,case)
    joint_bounds(a.output,pd.read_csv(a.review/'small_audit.csv'))
    calibration_plot(a.output,val)
