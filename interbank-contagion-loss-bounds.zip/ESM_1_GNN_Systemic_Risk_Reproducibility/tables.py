"""Generate all revised manuscript tables and numerical text from the saved runs."""

import json
from pathlib import Path

from review_experiments import (
    ALL_METHODS, FLAT, GNN, MLP, MATCHED, SPARSE, LARGEST_KNOWN,
    LARGEST_UNKNOWN, FACTOR_DENSITIES, FACTOR_SHARES, FACTOR_DISCLOSURES,
    TURKIYE_SHARES,
)
from reconstruction_extension import CALIBRATION_NAME

ROOT=Path(__file__).resolve().parent
RESULTS=ROOT/'review_results'


def read(path):
    return json.loads(path.read_text())


PRIMARY=read(RESULTS/'results'/'summary.json')['conditions']
REPLICATION=read(RESULTS/'replication'/'summary.json')['conditions']
VALIDATION=read(RESULTS/'validation'/'summary.json')['conditions']
AUDIT=read(RESULTS/'audit_summary.json')
MAIN=PRIMARY['Modular 50%']
REPEAT=REPLICATION['Modular 50%']
CROSS=VALIDATION[CALIBRATION_NAME]
UNKNOWN=PRIMARY[LARGEST_UNKNOWN]
KNOWN=PRIMARY[LARGEST_KNOWN]
SMALL=AUDIT['small']['All audit cases']
LARGE=AUDIT['large']

SHORT_NAME={LARGEST_UNKNOWN:'Largest-first, rule unknown',LARGEST_KNOWN:'Largest-first, cutoff known'}


def label(name):
    return SHORT_NAME.get(name,name)


def num(value, digits=2):
    return f'{value:.{digits}f}'.replace('-','−')


def ma(condition, method, digits=2):
    return num(condition['models'][method]['mae'],digits)


def paired(condition,method,digits=3):
    lo,hi=condition['gnn_differences'][method]['ci']
    return f'[{num(lo,digits)}, {num(hi,digits)}]'


def percentage(record,key):
    return num(100*record[key]/record['cases'])


def fallbacks(condition):
    cases=[x['projection'] for x in condition['models'].values() if x['projection']]
    return f"{sum(x['l1_fallbacks'] for x in cases):,} of {sum(x['allocations'] for x in cases):,}"


def robustness(conditions):
    return [
        ('Condition','Flat','Original MLP','Matched MLP','Reciprocal','GNN','Width'),
        *[(label(name),*[ma(d,model) for model in (FLAT,MLP,MATCHED,SPARSE,GNN)],num(d['bounds_width']))
          for name,d in conditions.items()],
    ]


def factor(density,share,coverage):
    return VALIDATION[f'Factor {100*density:.1f}% density, {100*share:.2f}% exposures, {100*coverage:.0f}% disclosed']


FACTORS=[(density,share,coverage,factor(density,share,coverage))
         for density in FACTOR_DENSITIES for share in FACTOR_SHARES for coverage in FACTOR_DISCLOSURES]
TURKIYE=[(share,VALIDATION[f'Türkiye {100*share:.2f}% exposures']) for share in TURKIYE_SHARES]


TABLES={
  1: ('Closest methods for reconstruction and risk under incomplete exposure information', (3.10,6.22,6.60), [
      ('Strand','Selected prior work','Role in the present study'),
      ('Clearing and contagion','Eisenberg and Noe (2001), Rogers and Veraart (2013), Acemoglu et al. (2015)',
       'Apply proportional clearing to a fixed scenario and measure incremental outside losses.'),
      ('Robust risk and sensitivities','Ahn, Chen, and Kim (2024), Feinstein et al. (2018), Mastromatteo et al. (2012)',
       'Use exact margins and published links to bound a fixed-shock loss. Audit tightness with feasible completions.'),
      ('Exposure reconstruction','Anand et al. (2015, 2018), Gandy and Veraart (2017), Macchiati et al. (2024)',
       'Use common accounting margins and compare the fitted reciprocal sparse support with dense priors.'),
      ('Data-driven network risk','Cheng et al. (2023), Zhao et al. (2024), Likhitkar et al. (2025), Akgüller and Balcı (2026)',
       'Estimate exposures with directed messages and test the gain against a capacity-matched model.'),
  ]),
  3: ('Held-out disclosure conditions. The largest-first cases share the same 180 networks and observations', (5.12,1.90,1.55,3.24,4.11), [
      ('Condition','Networks','Banks','Links disclosed (%)','Value disclosed (%)'),
      *[(label(name),str(d['networks']),str(d['banks']),f'{100*d["coverage"]:.0f}',num(d['disclosure_value_pct']))
        for name,d in PRIMARY.items()],
  ]),
  4: ('Point accuracy and inference time at 50% uniform disclosure in the primary 32-bank test', (3.04,1.83,1.73,2.05,1.75,2.52,3.00), [
      ('Method','MAE (bp)','Bias (bp)','P90 error (bp)','Indirect AP','Hidden mass moved (%)','Time (ms/network)'),
      *[(name,num(d['mae'],3),num(d['bias']),num(d['p90']),num(d['ap'],3),
         num(d['realloc_pct']) if 'realloc_pct' in d else '—',num(d['elapsed_ms_per_network']))
        for name in ALL_METHODS for d in [MAIN['models'][name]]],
  ]),
  5: ('Primary point mean absolute errors and combined mean interval widths in basis points', (4.06,1.73,1.99,1.99,2.13,1.77,2.25), robustness(PRIMARY)),
  6: ('Primary classifications at the illustrative 25 bp threshold as percentages of scenario counts', (4.64,2.36,2.05,3.04,3.83), [
      ('Condition','At or below','Above','Needs disclosure','Needs disclosure, column only'),
      *[(label(name),*[percentage(d['screening']['25'],key) for key in ('at_or_below','above','needs_disclosure')],
         percentage(d['column_screening']['25'],'needs_disclosure')) for name,d in PRIMARY.items()],
  ]),
  7: ('Replication point mean absolute errors and combined mean interval widths in basis points', (4.06,1.73,1.99,1.99,2.13,1.77,2.25), robustness(REPLICATION)),
  8: ('Bounds versus exact maxima on small hidden blocks. All loss statistics are in basis points', (3.46,1.39,2.10,2.23,2.34,2.19,2.21), [
      ('Banks and block','Cases','Mean exact max.','Mean gap, column','Mean gap, combined','Largest gap, combined','Mean lower gap'),
      *[(key,str(d['cases']),num(d['mean_joint_max']),num(d['original_gap']),num(d['new_gap']),
         num(d['max_gap']),num(d['mean_lower_gap'])) for key,d in AUDIT['small'].items()],
  ]),
  9: ('Tightened upper bounds and feasible adverse losses on 32-bank masks. Losses and gaps are in basis points', (4.52,1.66,2.32,2.47,2.47,2.48), [
      ('Experiment and mask','Cases','Mean upper','Mean feasible adverse','Mean gap','P90 gap'),
      *[(('Primary' if d['run']=='results' else 'Replication')+', '+(label(d['condition']).lower()),
         str(d['cases']),num(d['mean_upper']),num(d['mean_adverse']),num(d['mean_gap']),num(d['p90_gap'])) for d in LARGE],
  ]),
  10: ('Published targets and realised synthetic values in the two calibrations', (2.74,3.67,2.20,2.42,4.89), [
      ('Calibration','Quantity','Target','Generated value','Published source'),
      ('Cross-market','Active banks','65.4',str(CROSS['banks']),'Forte (2020), Argentine overnight market'),
      ('Cross-market','Density (%)','5.50',num(CROSS['true_topology']['density_pct'],3),'Forte (2020), 2003–2017'),
      ('Cross-market','Reciprocity (%)','7.90',num(CROSS['true_topology']['reciprocity_pct']),'Forte (2020), 2003–2017'),
      ('Cross-market','Exposure share (%)','2.64',num(CROSS['exposure_assets_pct']),'Batiz-Zuk et al. (2016), Mexico'),
      ('Türkiye','Banks','47.7',str(TURKIYE[0][1]['banks']),'Sümer and Özyıldırım (2022), Table 4'),
      ('Türkiye','Density (%)','18.10',num(TURKIYE[0][1]['true_topology']['density_pct'],3),'Sümer and Özyıldırım (2022), Table 3'),
      ('Türkiye','Exposure share (%)','0.90–3.10','0.90 / 2.00 / 3.10','Sümer and Özyıldırım (2022), Sect. 2'),
  ]),
  11: ('Controlled sensitivity with 48 synthetic 65-bank networks per cell. Losses, MAEs and widths are in basis points', (1.74,2.17,2.17,2.12,1.91,1.95,1.90,1.96), [
      ('Density (%)','Exposure share (%)','Disclosed (%)','Mean loss','GNN MAE','Matched MAE','Mean width','Unclear at 25 bp (%)'),
      *[(num(100*density,1),num(100*share),num(100*coverage,0),num(d['true_loss_mean']),
         ma(d,GNN,3),ma(d,MATCHED,3),num(d['bounds_width']),percentage(d['screening']['25'],'needs_disclosure'))
        for density,share,coverage,d in FACTORS],
  ],False),
  12: ('Point accuracy and interval width in the calibrated synthetic networks. Loss statistics are in basis points', (4.23,2.01,1.79,1.93,1.93,1.94,2.09), [
      ('Calibration','Mean loss','Flat MAE','Matched MAE','GNN MAE','Reciprocal MAE','Mean width'),
      *[(name,num(d['true_loss_mean']),*[ma(d,method,3) for method in (FLAT,MATCHED,GNN,SPARSE)],num(d['bounds_width']))
        for name,d in [('Cross-market reference',CROSS),*[(f'Türkiye, {100*share:.2f}% exposures',d) for share,d in TURKIYE]]],
  ]),
}


TABLES[2] = ('Synthetic network and stress-test specification', (3.22,6.9,5.80), [
    ('Component','Setting','Role'),
    ('Bank sizes','Log size drawn from N(0, 0.83²), clipped to [−1.8, 1.9], then exponentiated','Heterogeneous exposures and bank assets'),
    ('Interbank liabilities','23–57% of size. Divide over at least two out-neighbours using noisy positive link weights.','Preserves positive external liabilities after construction'),
    ('Initial equity','4.5–11.5% of total pre-shock assets','Provides heterogeneous solvency buffers'),
    ('Modular topology','Four publicly observed sectors and a bank-specific latent creditor-sector preference','Training domain and the same-mechanism size shift'),
    ('Core–periphery','Core is the top size quintile. Links favour core creditors and core-to-core pairs.','Topology shift with altered counterparty preferences'),
    ('Single-bank stress','1–6.5% background haircut. A size-weighted target receives a 24–54% haircut.','Concentrated direct distress'),
    ('Sector stress','1.5–7% background haircut, plus 7–21 percentage points in one sector','Sector concentration'),
    ('Common-factor stress','3.5–14.5% common haircut plus Gaussian noise with standard deviation 3.8 percentage points','Broad stress. All haircuts clipped to [0, 65%].'),
  ])


margin=max(m['margin_residual'] for run in (PRIMARY,REPLICATION)
           for case in run.values() for m in case['models'].values() if m['margin_residual'] is not None)
sparse=MAIN['models'][SPARSE]
VALUES={
    'width_column':num(MAIN['column_width']), 'width_primary':num(MAIN['bounds_width']),
    'rep_column':num(REPEAT['column_width']), 'rep_width':num(REPEAT['bounds_width']),
    'p90_column':num(MAIN['p90_column_width']), 'p90_width':num(MAIN['p90_width']),
    'primary_gnn':ma(MAIN,GNN,3), 'primary_flat':ma(MAIN,FLAT,3), 'primary_matched':ma(MAIN,MATCHED,3),
    'primary_mlp':ma(MAIN,MLP,3), 'primary_sparse':ma(MAIN,SPARSE,3), 'primary_truth':num(MAIN['true_loss_mean']),
    'primary_flat_ci':paired(MAIN,FLAT,2), 'primary_matched_ci':paired(MAIN,MATCHED), 'primary_sparse_ci':paired(MAIN,SPARSE),
    'primary_indirect':num(100*MAIN['indirect_prevalence']), 'primary_moved':num(MAIN['models'][GNN]['realloc_pct']),
    'primary_gnn_ap':num(MAIN['models'][GNN]['ap'],3),
    'sparse_den_before':num(sparse['sampled_topology']['density_pct']),
    'sparse_den_after':num(sparse['fit_topology']['density_pct']),
    'sparse_den_true':num(sparse['true_topology']['density_pct']),
    'sparse_rec_before':num(sparse['sampled_topology']['reciprocity_pct']),
    'sparse_rec_after':num(sparse['fit_topology']['reciprocity_pct']),
    'sparse_rec_true':num(sparse['true_topology']['reciprocity_pct']),
    'gnn75':ma(PRIMARY['Modular 75%'],GNN,3), 'matched75':ma(PRIMARY['Modular 75%'],MATCHED,3),
    'match25_ci':paired(PRIMARY['Modular 25%'],MATCHED), 'match75_ci':paired(PRIMARY['Modular 75%'],MATCHED),
    'primary_core_gnn':ma(PRIMARY['Core-periphery 50%'],GNN,3), 'primary_core_flat':ma(PRIMARY['Core-periphery 50%'],FLAT,3),
    'largest_value':num(UNKNOWN['disclosure_value_pct']), 'violating_n':str(UNKNOWN['models'][GNN]['cutoff_networks']),
    'violation_ratio':num(UNKNOWN['models'][GNN]['cutoff_ratio_max']),
    'unknown_mae':ma(UNKNOWN,GNN,3), 'known_mae':ma(KNOWN,GNN,3),
    'unknown_width':num(UNKNOWN['bounds_width']), 'known_width':num(KNOWN['bounds_width']),
    'screen_old':percentage(MAIN['column_screening']['25'],'needs_disclosure'),
    'screen_new':percentage(MAIN['screening']['25'],'needs_disclosure'),
    'fall_main':fallbacks(MAIN), 'fall_cut':fallbacks(KNOWN), 'max_margin':f'{margin*1e9:.2f} × 10⁻⁹',
    'rep_gnn':ma(REPEAT,GNN,3), 'rep_matched':ma(REPEAT,MATCHED,3), 'rep_matched_ci':paired(REPEAT,MATCHED),
    'rep_sparse':ma(REPEAT,SPARSE,3), 'rep75_ci':paired(REPLICATION['Modular 75%'],MATCHED),
    'small_old_gap':num(SMALL['original_gap']), 'small_new_gap':num(SMALL['new_gap']), 'small_max':num(SMALL['max_gap']),
    'small_tail':num(SMALL['over_one_pct']), 'small_lower':num(SMALL['mean_lower_gap']),
    'worst_tight':num(AUDIT['original_worst_case']['tight_upper']), 'worst_exact':num(AUDIT['original_worst_case']['maximum_feasible']),
    'adverse_primary':num(LARGE[0]['mean_adverse']), 'adverse_upper':num(LARGE[0]['mean_upper']),
    'adverse_known_gap':num(LARGE[-1]['mean_gap']),
    'cross_gnn':ma(CROSS,GNN,3), 'cross_matched':ma(CROSS,MATCHED,3),
    'factor_low_true':num(factor(.055,.0264,.25)['true_loss_mean']), 'factor_high_true':num(factor(.055,.2222,.25)['true_loss_mean']),
    'turkiye_low_true':num(TURKIYE[0][1]['true_loss_mean']), 'turkiye_high_true':num(TURKIYE[-1][1]['true_loss_mean']),
}
