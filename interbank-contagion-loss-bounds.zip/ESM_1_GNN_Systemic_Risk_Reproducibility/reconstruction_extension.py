"""Reciprocal sparse reconstruction and a published-statistic stress benchmark."""

import argparse
import json
from pathlib import Path
from time import perf_counter

import numpy as np
import pandas as pd
from scipy.optimize import check_grad, linprog, minimize
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from scipy.special import logsumexp
from sklearn.metrics import average_precision_score

from study import (CONFIG, COVERAGES, EPS, METHODS, Network, amplification, clearing,
                   evaluate, features, intervals, make_network, neural_prior, scale_prior,
                   upper_envelope)


NAME = 'Reciprocal sparse'
DRAW_COUNT = 6
CALIBRATION_SEED = 351209
CALIBRATION_COUNT = 96
CALIBRATION_NAME = 'Published calibration 50%'
REFERENCE_BANKS = 65.4
REFERENCE_DENSITY = .055
REFERENCE_RECIPROCITY = .079
REFERENCE_EXPOSURE_SHARE = .0264
DESIGN_FEATURES = ('Intercept','Log residual liabilities','Log residual claims','Same sector','Observed sector share')
CONDITIONS = (('Modular 25%',2,.25,'Uniform'), ('Modular 50%',2,.50,'Uniform'), ('Modular 75%',2,.75,'Uniform'),
              ('Large-first 50%',2,.50,'Large-first'),('Core-periphery 50%',3,.50,'Uniform'),('48-bank 50%',4,.50,'Uniform'))


def design(data):
    """Pair features and admissible states computed from the disclosure."""
    i,j = np.triu_indices(data['allowed'].shape[-1],1)
    r,c = data['r'],data['c']
    allowed_f,allowed_b = data['allowed'][:,i,j],data['allowed'][:,j,i]
    flags = np.stack((np.ones_like(allowed_f),allowed_f,allowed_b,allowed_f&allowed_b),axis=-1)
    a = np.log(np.maximum(r/np.maximum(r.mean(axis=1,keepdims=True),EPS),1e-7))
    b = np.log(np.maximum(c/np.maximum(c.mean(axis=1,keepdims=True),EPS),1e-7))
    pair = data['pair']
    features_f = np.stack((np.ones_like(a[:,i]),a[:,i],b[:,j],pair[:,i,j,0],pair[:,i,j,5]),axis=-1)
    features_b = np.stack((np.ones_like(a[:,i]),a[:,j],b[:,i],pair[:,j,i,0],pair[:,j,i,5]),axis=-1)
    reverse_f = data['observed'][:,j,i]>0
    reverse_b = data['observed'][:,i,j]>0
    return (features_f,features_b,flags,reverse_f,reverse_b),(i,j)


def log_states(beta, inputs):
    f,b,flags,rev_f,rev_b = inputs
    eta_f,eta_b = f@beta[:-1],b@beta[:-1]
    gamma = beta[-1]
    logits = np.stack((np.zeros_like(eta_f),eta_f+gamma*rev_f,eta_b+gamma*rev_b,eta_f+eta_b+gamma),axis=-1)
    return np.where(flags,logits,-1e6)


def fit_support(nets):
    pieces = []
    states = []
    for coverage in COVERAGES:
        data = features(nets,coverage,'Uniform')
        inputs,(i,j) = design(data)
        valid = inputs[2][...,1]|inputs[2][...,2]
        pieces.append([v[valid] for v in inputs])
        f,b = data['hidden'][:,i,j]>1e-12,data['hidden'][:,j,i]>1e-12
        states.append((f.astype(int)+2*b)[valid])
    inputs = tuple(np.concatenate([x[i] for x in pieces]) for i in range(len(pieces[0])))
    state = np.concatenate(states)
    idx = np.arange(len(state))
    assert np.all(inputs[2][idx,state])
    f,b,_,rev_f,rev_b = inputs
    ridge = 1e-6

    def objective(beta, rows):
        args = tuple(v[rows] for v in inputs)
        target = state[rows]
        logits = log_states(beta,args)
        logz = logsumexp(logits,axis=1)
        probabilities = np.exp(logits-logz[:,None])
        loss = (logz-logits[np.arange(len(target)),target]).mean() + .5*ridge*(beta@beta)
        probabilities[np.arange(len(target)),target] -= 1
        df = probabilities[:,1]+probabilities[:,3]
        db = probabilities[:,2]+probabilities[:,3]
        gamma_grad = (probabilities[:,1]*rev_f[rows]+probabilities[:,2]*rev_b[rows]+probabilities[:,3]).mean()
        gradient = np.r_[(f[rows].T@df+b[rows].T@db)/len(target),gamma_grad] + ridge*beta
        return loss,gradient

    beta0 = np.zeros(len(DESIGN_FEATURES)+1)
    subset = slice(0,min(2500,len(state)))
    grad_error = check_grad(lambda b:objective(b,subset)[0],lambda b:objective(b,subset)[1],beta0)
    assert grad_error<1e-6
    ans = minimize(lambda b:objective(b,slice(None)), beta0, jac=True,method='L-BFGS-B',
                   bounds=[(-12,12)]*len(beta0),options={'ftol':1e-12,'gtol':1e-7,'maxiter':180})
    if not ans.success:
        raise RuntimeError(ans.message)
    logits = log_states(ans.x,inputs)
    probs = np.exp(logits-logsumexp(logits,axis=1,keepdims=True))
    observed_support_events = (state>0).sum()+(state==3).sum()
    return ans.x,dict(coefficients=dict(zip((*DESIGN_FEATURES,'Mutual interaction'),ans.x.tolist())),
                      training_dyads=len(idx),gradient_error=float(grad_error),objective=float(ans.fun),
                      observed_hidden_edges=int(observed_support_events),
                      predicted_hidden_edges=float((probs[:,1]+probs[:,2]+2*probs[:,3]).sum()),
                      observed_joint_hidden_pairs=int((state==3).sum()),predicted_joint_hidden_pairs=float(probs[:,3].sum()))


def repair_sample(sampled, allowed, prob, row, col, eq, i, j, cutoff=np.inf):
    """Use a feasible transport to repair margins, then remove structurally impossible edges."""
    total = row.sum()
    if total<=EPS:
        return sampled,0
    cost = (~sampled[i,j])*(1+.25*(1-prob[i,j]))
    upper = None if np.isinf(cutoff) else cutoff/total
    result = linprog(cost,A_eq=eq,b_eq=np.r_[row,col]/total,bounds=(0,upper),method='highs',
                     options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    if not result.success:
        raise RuntimeError(result.message)
    positive = result.x>0
    support = sampled.copy()
    support[i[positive],j[positive]] = True
    add = int((support&~sampled).sum())
    n = len(row)
    forward = support.copy()
    if upper is not None:
        saturated = result.x >= upper-1e-13
        forward[i[saturated],j[saturated]] = False
    a,b = np.where(forward)
    origins = np.r_[a,n+j[positive]]
    targets = np.r_[n+b,i[positive]]
    graph = coo_matrix((np.ones(len(origins)),(origins,targets)),shape=(2*n,2*n)).tocsr()
    _,labels = connected_components(graph,directed=True,connection='strong')
    feasible_face = support & (labels[:n,None]==labels[None,n:])
    feasible_face[i[positive],j[positive]] = True
    assert np.all(feasible_face[i[positive],j[positive]])
    assert not np.any(feasible_face & ~allowed)
    return feasible_face,add


def sample_supports(data, beta, rng, draws):
    inputs,(i,j) = design(data)
    logits = log_states(beta,inputs)
    p = np.exp(logits-logsumexp(logits,axis=-1,keepdims=True))
    batch,n,_ = data['allowed'].shape
    prob = np.zeros((batch,n,n))
    prob[:,i,j] = p[...,1]+p[...,3]
    prob[:,j,i] = p[...,2]+p[...,3]
    segments = p[...,:3].cumsum(axis=-1)
    states = (rng.random((batch,draws,len(i),1))>segments[:,None]).sum(axis=-1)
    sampled = np.zeros((batch,draws,n,n),dtype=bool)
    sampled[:,:,i,j] = (states==1)|(states==3)
    sampled[:,:,j,i] = (states==2)|(states==3)
    sampled &= data['allowed'][:,None]
    repaired=sampled.copy()
    diagnostics=np.zeros((batch,draws),dtype=int)
    cutoff=data.get('cutoff', np.full(batch, np.inf))
    for k, allowed in enumerate(data['allowed']):
        a,b = np.where(allowed)
        e = np.arange(len(a))
        eq = coo_matrix((np.ones(2*len(a)),(np.r_[a,n+b],np.r_[e,e])),shape=(2*n,len(a))).tocsc()
        for z in range(draws):
            repaired[k,z], diagnostics[k,z] = repair_sample(sampled[k,z],allowed,prob[k],data['r'][k],data['c'][k],eq,a,b,cutoff[k])
    return sampled,repaired,diagnostics


def topology_stats(matrix):
    links = matrix>1e-10
    n=links.shape[-1]
    edges=links.sum(axis=(-1,-2))
    mutual=(links & links.swapaxes(-1,-2)).sum(axis=(-1,-2))
    return dict(density_pct=float(np.mean(edges/(n*(n-1)))*100),
                reciprocity_pct=float(np.mean(mutual/np.maximum(edges,1))*100))


def sparse_predict(data, beta, amount_logits, rng, draws):
    reported=data['observed']
    started = perf_counter()
    before,support,added=sample_supports(data,beta,rng,draws)
    batch,_,n,_=support.shape
    amount=np.broadcast_to(amount_logits[:,None],support.shape).reshape(-1,n,n)
    allowed=support.reshape(-1,n,n)
    rows=np.repeat(data['r'],draws,axis=0)
    cols=np.repeat(data['c'],draws,axis=0)
    output=np.zeros_like(amount)
    max_err=0
    solver = {}
    cutoff = np.repeat(data['cutoff'], draws) if 'cutoff' in data else None
    for start in range(0,len(amount),36):
        stop=start+36
        problem = dict(allowed=allowed[start:stop],r=rows[start:stop],c=cols[start:stop])
        if cutoff is not None:
            problem['cutoff'] = cutoff[start:stop]
        output[start:stop],err=scale_prior(amount[start:stop],problem,solver)
        max_err=max(max_err,err)
    reconstruction=reported[:,None]+output.reshape(batch,draws,n,n)
    elapsed = perf_counter()-started
    true_rows=reported.sum(axis=2)+data['r']
    true_cols=reported.sum(axis=1)+data['c']
    assert np.max(np.abs(reconstruction.sum(axis=-1)-true_rows[:,None]))<1e-6
    assert np.max(np.abs(reconstruction.sum(axis=-2)-true_cols[:,None]))<1e-6
    assert np.all(np.diagonal(reconstruction,axis1=-2,axis2=-1)==0)
    truth,_,_=clearing(data['full'],data['d'],data['payable'])
    lower,_,_=clearing(reported,data['d'],data['payable'])
    keys = tuple(k for k in ('d','payable','observed','c','r','allowed','cutoff') if k in data)
    upper=np.concatenate([upper_envelope({k:data[k][i:i+24] for k in keys})
                          for i in range(0,batch,24)])
    direct=(data['d']/data['payable'][:,None]).clip(0,1)
    started = perf_counter()
    est,score,resid=clearing(reconstruction.reshape(-1,n,n),np.repeat(data['d'],draws,axis=0),np.repeat(data['payable'],draws,axis=0))
    avg=est.reshape(batch,draws,-1,n).mean(axis=1)
    score=score.reshape(batch,draws,-1,n).mean(axis=1)
    elapsed += perf_counter()-started
    assert np.max(lower-avg)<2e-8 and np.max(avg-upper)<2e-8
    target=amplification(truth,direct,data['external'])
    pred=amplification(avg,direct,data['external'])
    err=pred-target
    candidate=data['d']<=0
    event=truth[candidate]>CONFIG['event_tolerance']
    mass_moved=np.abs(reconstruction.mean(axis=1)-data['full']).sum(axis=(1,2))/(2*np.maximum(data['hidden'].sum(axis=(1,2)),EPS))
    max_hidden = output.reshape(batch,draws,n,n).max(axis=(1,2,3))
    max_cutoff_excess = float(np.max(np.maximum(max_hidden-data['cutoff'],0.))) if cutoff is not None else None
    out=dict(mae=float(np.abs(err).mean()),bias=float(err.mean()),p90=float(np.quantile(np.abs(err),.9)),
             ap=float(average_precision_score(event,score[candidate])) if event.any() else None,
             realloc_pct=float(100*mass_moved.mean()),margin_residual=max_err,solver_residual=resid,
             support_added_mean=float(added.mean()),fit_topology=topology_stats(reconstruction),
             sampled_topology=topology_stats(before | (reported[:,None]>0)),
             true_topology=topology_stats(data['full']), projection=solver,
             elapsed_ms_per_network=elapsed*1000/batch,max_cutoff_excess=max_cutoff_excess)
    return out,pred,target


def calibrated_network(rng, n=round(REFERENCE_BANKS), density=REFERENCE_DENSITY,
                       reciprocity=REFERENCE_RECIPROCITY, exposure_share=REFERENCE_EXPOSURE_SHARE):
    stock=make_network(n,rng,'modular')
    baseline_liabilities=stock.liabilities.sum(axis=1)
    size=stock.asset-baseline_liabilities
    capital=stock.equity/(stock.asset+stock.liabilities.sum(axis=0))
    i,j=np.triu_indices(n,1)
    shared=stock.sector[i]==stock.sector[j]
    # Exact link and mutual-dyad counts; sector and size weights vary endpoints.
    weight=np.exp(.36*(np.log(size[i])+np.log(size[j]))+.45*shared)
    links_total=round(density*n*(n-1))
    mutual_num=None if reciprocity is None else round(reciprocity*links_total/2)
    if mutual_num is None:
        spread=.14*(np.log(size[j])-np.log(size[i]))
        directed_weight=np.r_[weight*np.exp(spread),weight*np.exp(-spread)]
        debtors,creditors=np.r_[i,j],np.r_[j,i]
    for _ in range(500):
        links=np.zeros((n,n),dtype=bool)
        if mutual_num is None:
            directed=rng.choice(len(debtors),size=links_total,replace=False,p=directed_weight/directed_weight.sum())
            links[debtors[directed],creditors[directed]]=True
        else:
            chosen=rng.choice(len(i),size=links_total-mutual_num,replace=False,p=weight/weight.sum())
            mutual,ch=chosen[:mutual_num],chosen[mutual_num:]
            go_forward=rng.random(len(ch))<1/(1+np.exp(.45*(np.log(size[i[ch]])-np.log(size[j[ch]]))))
            links[i[mutual],j[mutual]]=True
            links[j[mutual],i[mutual]]=True
            links[i[ch[go_forward]],j[ch[go_forward]]]=True
            links[j[ch[~go_forward]],i[ch[~go_forward]]]=True
        if np.all(links.any(axis=0)|links.any(axis=1)):
            break
    else:
        raise RuntimeError('No active network sample found')
    numerator=exposure_share * size.sum()/(1-exposure_share)
    ib=baseline_liabilities*links.any(axis=1)
    ib *= numerator/ib.sum()
    wealth=np.exp(rng.normal(0,.83,(n,n))+.38*(stock.sector[:,None]==stock.sector[None])+ .26*np.log(size)[None])*links
    full=wealth*(ib/np.maximum(wealth.sum(axis=1),EPS))[:,None]
    asset=size
    equity=(asset+full.sum(axis=0))*capital
    payable=asset+full.sum(axis=0)-equity
    external=payable-full.sum(axis=1)
    assert np.all(external>0)
    assert np.isclose(full.sum()/(asset.sum()+full.sum()),exposure_share)
    assert (full>0).sum()==links_total
    assert mutual_num is None or 2*mutual_num==(links & links.T).sum()
    return Network(full,asset,equity,external,payable,stock.sector,stock.shock,rng.permutation(np.flatnonzero(links.ravel())))


def load_models(folder):
    result={name:[] for name in METHODS[2:]}
    with np.load(folder/'model_weights.npz') as z:
        for method,params in result.items():
            count=1 if method=='Pairwise RAS' else 3
            for i in range(count):
                pattern=f'{method}_{i}_'
                params.append({k[len(pattern):]:z[k] for k in z.files if k.startswith(pattern)})
                assert params[-1]
    return result


def run_case(folder, calibrated, random_seed, draws, pilot, replication):
    summary=json.loads((folder/'summary.json').read_text())
    params=summary['config']
    seed=params['network_seed']
    count_factor=.10 if pilot else 1
    streams=np.random.SeedSequence(seed).spawn(5)
    train=[make_network(32,np.random.default_rng(s),'modular') for s in streams[0].spawn(round(params['train']*count_factor))]
    test={idx:[make_network(n,np.random.default_rng(s),topo) for s in streams[idx].spawn(round(params[key]*count_factor))]
          for idx,n,topo,key in [(2,32,'modular','test_modular'),(3,32,'core','test_core'),(4,48,'modular','test_size')]}
    beta,structure=fit_support(train)
    models=load_models(folder)
    known=pd.read_csv(folder/'scenario_results.csv.gz')
    result={}
    records=[]
    rng=np.random.default_rng(random_seed)
    calibration_case = not replication
    if calibration_case:
        test[5]=calibrated
    settings=CONDITIONS+(((CALIBRATION_NAME,5,.50,'Uniform'),) if calibration_case else ())
    for name,idx,coverage,mechanism in settings:
        nets=test[idx]
        if name==CALIBRATION_NAME:
            stat,original=evaluate(name,nets,coverage,mechanism,models,CONFIG,np.random.default_rng(random_seed+12))
            keys=('condition','network_id','scenario_id','shock','method','true_risk_bps','estimated_risk_bps',
                  'lower_bps','upper_bps','indirect_events','direct_solvent','direct_defaults')
            existing=pd.DataFrame(original,columns=keys)
            published=stat
            records.append(existing)
        else:
            existing=known[known.condition.eq(name)&known.network_id.lt(len(nets))].copy()
        batch=features(nets,coverage,mechanism)
        value_logits=neural_prior(models['Pairwise RAS'][0],batch,'Pairwise RAS')[0]
        perf,pred,actual=sparse_predict(batch,beta,value_logits,rng,draws)
        template=existing.loc[existing.method.eq('GNN-RAS')].sort_values(['network_id','scenario_id']).copy()
        mismatch = np.max(abs(template.true_risk_bps.to_numpy()-actual.ravel()))
        assert mismatch < 2e-8, (name,mismatch)
        gnn=template.estimated_risk_bps.to_numpy().reshape(actual.shape)
        delta=(abs(gnn-actual)-abs(pred-actual)).mean(axis=1)
        perf['gnn_minus_sparse_ci']=intervals(delta,rng,CONFIG['bootstrap_draws'])
        perf['gnn_minus_sparse']=float(delta.mean())
        mlp=existing.loc[existing.method.eq('No-message MLP')].sort_values(['network_id','scenario_id'])
        delta_mlp=(abs(gnn-actual)-abs(mlp.estimated_risk_bps.to_numpy().reshape(actual.shape)-actual)).mean(axis=1)
        perf['gnn_minus_no_message_ci']=intervals(delta_mlp,rng,CONFIG['bootstrap_draws'])
        template['method']=NAME
        template['estimated_risk_bps']=pred.ravel()
        records.append(template)
        result[name]=perf
        if name==CALIBRATION_NAME:
            published['models'][NAME]=perf
            published['observed_topology']=topology_stats(batch['full'])
            published['mean_capital_pct']=float(np.mean([np.mean(net.equity/(net.asset+net.liabilities.sum(axis=0))) for net in nets])*100)
            published['benchmarks']=dict(banks=REFERENCE_BANKS,density_pct=100*REFERENCE_DENSITY,
                                         reciprocity_pct=100*REFERENCE_RECIPROCITY,exposures_assets_pct=100*REFERENCE_EXPOSURE_SHARE)
        print(f'{folder.name} | {name} | {len(nets)} nets | Sparse MAE {perf["mae"]:.4f} bp | '
              f'GNN − sparse {perf["gnn_minus_sparse"]:+.4f} bp',flush=True)
    obj=dict(network_seed=seed,draws=draws,structure_fit=structure,scenarios=result)
    if calibration_case:
        obj['calibrated_benchmark']=published
    return obj,pd.concat(records,ignore_index=True)


def run(root,out,pilot):
    rng=np.random.SeedSequence(CALIBRATION_SEED)
    calibrated=[calibrated_network(np.random.default_rng(s)) for s in rng.spawn(8 if pilot else CALIBRATION_COUNT)]
    all_results=dict(calibration_seed=CALIBRATION_SEED,pilot=pilot)
    records=[]
    for i,key in enumerate(('results','replication')):
        if pilot and i:
            break
        all_results[key],data=run_case(root/key,calibrated,616131+i,2 if pilot else DRAW_COUNT,pilot,i>0)
        data.insert(0,'run',key)
        records.append(data)
    out.mkdir(exist_ok=True,parents=True)
    pd.concat(records).to_csv(out/'extension_scenarios.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    (out/'reconstruction_extension.json').write_text(json.dumps(all_results,indent=2,allow_nan=False)+'\n')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path('.'))
    parser.add_argument('--output',type=Path,default=Path('extension'))
    parser.add_argument('--pilot',action='store_true')
    args=parser.parse_args()
    run(args.root,args.output,args.pilot)
