"""Audit the conservation cap and construct adverse feasible completions on larger masks."""

import argparse
import json
from pathlib import Path
from time import perf_counter

import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

from bound_audit import SEED, select_block
from reconstruction_extension import load_models
from review_experiments import (
    FLAT, GNN, LARGEST_KNOWN, allocate, bounded_clearing, prepare, screening,
)
from study import EPS, amplification, clearing, conservation_upper, make_network

AUDIT_NETWORKS = 32
AUDIT_LAYOUT = (
    ('results', 'Modular 50%', 2, 'modular', 'Uniform', False),
    ('replication', 'Modular 50%', 2, 'modular', 'Uniform', False),
    ('results', 'Core-periphery 50%', 3, 'core', 'Uniform', False),
    ('results', LARGEST_KNOWN, 2, 'modular', 'Large-first', True),
)


def audit_small(path):
    old = pd.read_csv(path)
    rng = np.random.default_rng(SEED)
    caps = []
    for (n, columns), group in old.groupby(['banks','hidden_receivers']):
        for _, scenarios in group.groupby('network_id'):
            block = None
            while block is None:
                net = make_network(int(n),rng,'modular')
                block = select_block(net,int(columns),rng)
            _, _, _, _, obs = block
            d = net.shock*net.asset-net.equity
            low,_,_=clearing(obs[None],d[None],net.payable[None])
            q0=(d/net.payable).clip(0,1)[None]
            simulated_low=amplification(low,q0,net.outside[None])[0]
            assert np.max(abs(simulated_low-scenarios.lower.to_numpy()))<2e-8
            r=(net.liabilities-obs).sum(axis=1)
            cap=conservation_upper(dict(payable=net.payable[None],external=net.outside[None],
                                        observed=obs[None],r=r[None],d=d[None]),low)[0]
            caps.extend(cap)
    old['conservation'] = caps
    old['tight_upper'] = np.minimum(old.upper,old.conservation)
    assert (old.maximum_feasible<=old.tight_upper+1e-7).all()
    assert (old.minimum_feasible>=old.lower-1e-7).all()
    return old


class Transport:
    """A fixed support, margins and optional upper capacities for one disclosure."""

    def __init__(self, observed, row, col, allowed, cutoff=np.inf):
        self.observed=observed
        self.row=row
        self.col=col
        self.allowed=allowed
        self.cutoff=cutoff
        self.rows,self.cols=np.where(allowed)
        self.count=len(self.rows)
        self.n=len(row)
        idx=np.arange(self.count)
        self.total=max(row.sum(),EPS)
        self.eq=coo_matrix((np.ones(2*self.count),
                            (np.r_[self.rows,self.n+self.cols],np.r_[idx,idx])),
                           shape=(2*self.n,self.count)).tocsc()
        self.rhs=np.r_[row,col]/self.total
        self.bounds=(0,None if np.isinf(cutoff) else cutoff/self.total)

    def maximise(self, scores):
        if not self.count:
            return self.observed.copy()
        objective=scores[self.rows,self.cols]
        normal=np.max(np.abs(objective))
        result=linprog(-objective/max(normal,EPS),A_eq=self.eq,b_eq=self.rhs,
                       bounds=self.bounds,method='highs',
                       options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
        if not result.success:
            raise RuntimeError(result.message)
        matrix=self.observed.copy()
        matrix[self.rows,self.cols]=result.x*self.total
        self.verify(matrix)
        return matrix

    def verify(self,matrix):
        h=matrix-self.observed
        tol=6e-8*max(self.total,1.)
        assert np.min(h)>-tol and np.max(h-self.cutoff)<tol
        assert np.max(np.abs(h[~self.allowed]),initial=0.)<tol
        assert np.max(np.abs(h.sum(axis=1)-self.row))<tol
        assert np.max(np.abs(h.sum(axis=0)-self.col))<tol


def clear_choices(matrices,d,p,b):
    m=len(matrices)
    q,_,_=clearing(matrices,np.broadcast_to(d,(m,1,len(p))),np.broadcast_to(p,(m,len(p))))
    q=q[:,0]
    risk=(q-(d/p).clip(0,1))@b*1e4/b.sum()
    return risk,q


def find_adverse(problem, d, p, b, starts):
    # The extra start assigns borrowing from directly distressed banks to creditors
    # with little remaining equity. The search uses the disclosure and shock only.
    direct=(d/p).clip(0,1)
    near_deficit=np.exp(-18*np.maximum(-d/p,0)) * b/p
    shock_start=problem.maximise(direct[:,None]*near_deficit[None])
    choices=np.stack((*starts,shock_start))
    losses,shorts=clear_choices(choices,d,p,b)
    slot=int(np.argmax(losses))
    selected,q,best=choices[slot],shorts[slot],losses[slot]
    for _ in range(3):
        active=np.flatnonzero(q>1e-10)
        if not len(active):
            break
        adjoint=np.zeros_like(q)
        m=np.diag(p[active])-selected[np.ix_(active,active)]
        adjoint[active]=np.linalg.solve(m,b[active])
        vertex=problem.maximise(q[:,None]*adjoint[None])
        steps=np.array([.25,.5,1.])[:,None,None]
        alternatives=selected+steps*(vertex-selected)
        losses,shorts=clear_choices(alternatives,d,p,b)
        slot=int(np.argmax(losses))
        if losses[slot]<=best+1e-9:
            break
        selected,q,best=alternatives[slot],shorts[slot],losses[slot]
    problem.verify(selected)
    return float(best)


def audit_large(root):
    records=[]
    for part,condition,stream,topology,mechanism,known in AUDIT_LAYOUT:
        started=perf_counter()
        folder=root/part
        seed=json.loads((folder/'summary.json').read_text())['config']['network_seed']
        seeds=np.random.SeedSequence(seed).spawn(5)[stream].spawn(AUDIT_NETWORKS)
        nets=[make_network(32,np.random.default_rng(s),topology) for s in seeds]
        data=prepare(nets,.50,mechanism,known)
        models=load_models(folder)
        flat=allocate(FLAT,models,data,None)[0]
        gnn=allocate(GNN,models,data,None)[0]
        q0, lower, column, cap, upper=bounded_clearing(data)
        qtrue,_,_=clearing(data['full'],data['d'],data['payable'])
        truth=amplification(qtrue,q0,data['external'])
        for k,net in enumerate(nets):
            cutoff=data['cutoff'][k] if known else np.inf
            problem=Transport(data['observed'][k],data['r'][k],data['c'][k],data['allowed'][k],cutoff)
            problem.verify(flat[k])
            problem.verify(gnn[k])
            for s,d in enumerate(data['d'][k]):
                candidate=find_adverse(problem,d,net.payable,net.outside,(flat[k],gnn[k]))
                assert candidate<=upper[k,s]+2e-6, (part,condition,k,s,candidate,upper[k,s])
                records.append(dict(run=part,condition=condition,network_id=k,scenario_id=s,
                                    lower=lower[k,s],column=column[k,s],conservation=cap[k,s],
                                    upper=upper[k,s],adverse=candidate,truth=truth[k,s]))
        count=AUDIT_NETWORKS*9
        print(f'{part} | {condition} | {count} scenario searches in {perf_counter()-started:.1f} s',flush=True)
    return pd.DataFrame(records)


def summarize(small,large):
    out=dict(small={},large=[])
    groups=[(f'{n} banks, 2×{c}',g) for (n,c),g in small.groupby(['banks','hidden_receivers'])]
    for name,g in [*groups,('All audit cases',small)]:
        original=g.upper-g.maximum_feasible
        gap=g.tight_upper-g.maximum_feasible
        out['small'][name]=dict(cases=len(g),mean_joint_max=float(g.maximum_feasible.mean()),
                                original_gap=float(original.mean()),new_gap=float(gap.mean()),
                                p90_gap=float(gap.quantile(.9)),p90_original_gap=float(original.quantile(.9)),
                                max_gap=float(gap.max()),max_original_gap=float(original.max()),
                                over_one_pct=float(100*(gap>1).mean()),
                                mean_lower_gap=float((g.minimum_feasible-g.lower).mean()))
    worst=small.loc[(small.upper-small.maximum_feasible).idxmax()]
    out['original_worst_case']={key:float(worst[key]) for key in
                                 ('lower','upper','tight_upper','minimum_feasible','maximum_feasible')}
    for (run,condition),group in large.groupby(['run','condition'],sort=False):
        gaps=group.upper-group.adverse
        out['large'].append(dict(run=run,condition=condition,cases=len(group),
                                 width=float((group.upper-group.lower).mean()),
                                 mean_adverse=float(group.adverse.mean()),mean_upper=float(group.upper.mean()),
                                 mean_gap=float(gaps.mean()),p90_gap=float(gaps.quantile(.9)),
                                 max_gap=float(gaps.max()),
                                 found_no_less_than_truth_pct=float(100*np.mean(group.adverse>=group.truth-1e-7))))
    return out


def run(root,out):
    out.mkdir(parents=True,exist_ok=True)
    small=audit_small(root/'extension'/'bound_audit.csv')
    large=audit_large(root)
    small.to_csv(out/'small_audit.csv',index=False)
    large.to_csv(out/'large_audit.csv',index=False)
    summary=summarize(small,large)
    (out/'audit_summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    print('Small and large disclosure audits validated.',flush=True)


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--root',type=Path,default=Path('.'))
    cli.add_argument('--output',type=Path,default=Path('review_results'))
    args=cli.parse_args()
    run(args.root,args.output)
