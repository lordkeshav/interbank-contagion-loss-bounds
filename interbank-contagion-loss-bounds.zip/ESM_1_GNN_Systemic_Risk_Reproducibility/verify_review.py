"""Check the archived revised results and the capacity-constrained solver."""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from review_experiments import (
    ALL_METHODS, CONFIG, GNN, LARGEST_KNOWN, LARGEST_UNKNOWN, MATCHED,
    SPARSE, THRESHOLDS_BP, calibration_cases,
)
from study import scale_prior

TOLERANCE = 1e-7


def verify_projection():
    data = dict(r=np.array([[3.,3.]]),c=np.array([[3.,3.]]),
                allowed=np.ones((1,2,2),dtype=bool),cutoff=np.array([2.]))
    prior = np.log(np.array([[[100.,1.],[1.,100.]]]))
    diagnostics = {}
    fit, _ = scale_prior(prior,data,diagnostics)
    expected = np.array([[[2.,1.],[1.,2.]]])
    assert np.max(abs(fit-expected))<1e-7
    assert diagnostics['l1_fallbacks']==0
    original = CONFIG['scaling_max_iterations']
    try:
        CONFIG['scaling_max_iterations'] = 0
        fallback = {}
        fit,_=scale_prior(prior,data,fallback)
    finally:
        CONFIG['scaling_max_iterations'] = original
    assert np.max(fit)<=2.+1e-8
    assert np.allclose(fit.sum(axis=1),data['c']) and np.allclose(fit.sum(axis=2),data['r'])
    assert fallback['l1_fallbacks']==1


def verify_experiment(directory):
    meta=json.loads((directory/'summary.json').read_text())
    result=pd.read_csv(directory/'scenarios.csv.gz')
    key=['condition','network_id','scenario_id']
    targets=['true_bps','lower_bps','column_bps','conservation_bps','upper_bps']
    assert not result.duplicated(key+['method']).any()
    assert result.groupby(key).size().eq(len(ALL_METHODS)).all()
    assert result.groupby(key)[targets].nunique().eq(1).all().all()
    assert set(result.method)==set(ALL_METHODS)
    assert set(result.condition)==set(meta['conditions'])
    assert np.max(abs(result.upper_bps-np.minimum(result.column_bps,result.conservation_bps)))<TOLERANCE
    for field in ('true_bps','predicted_bps'):
        assert np.max(result.lower_bps-result[field])<TOLERANCE
        assert np.max(result[field]-result.upper_bps)<TOLERANCE
    for label,summary in meta['conditions'].items():
        subset=result[result.condition.eq(label)]
        assert len(subset)==summary['networks']*9*len(ALL_METHODS)
        assert subset.groupby(['network_id','method']).size().eq(9).all()
        err={}
        for method,group in subset.groupby('method'):
            entry=summary['models'][method]
            error=group.predicted_bps-group.true_bps
            assert np.isclose(entry['mae'],float(abs(error).mean()),rtol=0,atol=1e-10)
            assert np.isclose(entry['p90'],float(abs(error).quantile(.9)),rtol=0,atol=1e-10)
            assert np.isclose(entry['bias'],float(error.mean()),rtol=0,atol=1e-10)
            err[method]=np.abs(error).mean()
            projection=entry['projection']
            if projection:
                assert projection['allocations']==summary['networks']*(6 if method==SPARSE else 1)
                assert 0 <= projection['l1_fallbacks'] <= projection['allocations']
                assert entry['margin_residual']<1.5e-8
                assert entry['elapsed_ms_per_network']>0
        for method,contrast in summary['gnn_differences'].items():
            assert abs(err[GNN]-err[method]-contrast['mean'])<1e-10
            assert min(contrast['ci'])<=contrast['mean']<=max(contrast['ci'])
        unique=subset.drop_duplicates(key)
        assert np.isclose((unique.upper_bps-unique.lower_bps).mean(),summary['bounds_width'],rtol=0,atol=1e-10)
        for t in THRESHOLDS_BP:
            a=summary['screening'][str(t)]
            b=summary['column_screening'][str(t)]
            below=int((unique.upper_bps<=t).sum())
            above=int((unique.lower_bps>t).sum())
            assert a['at_or_below']==below and a['above']==above and a['cases']==len(unique)
            assert a['needs_disclosure']==len(unique)-below-above
            assert a['needs_disclosure']<=b['needs_disclosure']
        if label==LARGEST_KNOWN:
            assert summary['cutoff_known']
            for method,metric in summary['models'].items():
                if method==SPARSE:
                    assert metric['max_cutoff_excess']<TOLERANCE
                else:
                    assert metric['cutoff_networks']==0
    if LARGEST_KNOWN in meta['conditions']:
        mask=result[result.condition.isin([LARGEST_KNOWN,LARGEST_UNKNOWN])&result.method.eq(GNN)]
        unknown,known=(mask[mask.condition.eq(label)].sort_values(key[1:]) for label in (LARGEST_UNKNOWN,LARGEST_KNOWN))
        assert np.allclose(known.true_bps,unknown.true_bps,rtol=0,atol=TOLERANCE)
        assert np.max(known.upper_bps.to_numpy()-unknown.upper_bps.to_numpy())<TOLERANCE
        assert all(fit['parameters']==4101 for fit in meta['matched_fit']['fits'])
        assert meta['matched_fit']['gradient_check_max_abs']<2e-8
    print(f'{directory.name} — {len(result):,} revised method–scenario estimates validated')
    return meta


def verify_audits(root):
    small=pd.read_csv(root/'small_audit.csv')
    large=pd.read_csv(root/'large_audit.csv')
    summaries=json.loads((root/'audit_summary.json').read_text())
    assert len(small)==864 and len(large)==1152
    assert not small.duplicated(['banks','hidden_receivers','network_id','scenario_id']).any()
    assert not large.duplicated(['run','condition','network_id','scenario_id']).any()
    assert np.max(small.maximum_feasible-small.tight_upper)<TOLERANCE
    assert np.max(small.lower-small.minimum_feasible)<TOLERANCE
    assert np.max(large.adverse-large.upper)<2e-6
    assert np.max(large.truth-large.upper)<TOLERANCE
    assert np.max(large.lower-large.adverse)<TOLERANCE
    assert np.allclose(large.upper,np.minimum(large.column,large.conservation),rtol=0,atol=1e-10)
    for entry in summaries['large']:
        data=large[large.run.eq(entry['run'])&large.condition.eq(entry['condition'])]
        assert len(data)==entry['cases']
        assert abs((data.upper-data.adverse).mean()-entry['mean_gap'])<1e-10
    print('864 exact small-mask cases and 1,152 larger-mask adverse searches validated')


def verify_calibration(meta):
    supports={}
    for label,nets,fraction,_ in calibration_cases():
        reported=meta['conditions'][label]
        observed_size=len(nets[0].asset)
        assert reported['networks']==len(nets) and reported['banks']==observed_size
        assert fraction==reported['coverage']
        strength=np.array([net.liabilities.sum()/(net.asset.sum()+net.liabilities.sum()) for net in nets])
        assert abs(100*strength.mean()-reported['exposure_assets_pct'])<1e-10
        if label.startswith('Factor') or label.startswith('Türkiye'):
            tag='Turkey' if label.startswith('Türkiye') else label.split(' density,')[0]
            if tag in supports:
                reference=supports[tag]
                assert all(np.array_equal(first.liabilities>0,second.liabilities>0)
                           and np.array_equal(first.shock,second.shock)
                           and np.array_equal(first.order_uniform,second.order_uniform)
                           for first,second in zip(reference,nets))
            else:
                supports[tag]=nets
    print('Matched-support sensitivities and realised calibration targets validated')


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--review',type=Path,default=Path('review_results'))
    args=cli.parse_args()
    verify_projection()
    for name in ('results','replication','validation'):
        meta=verify_experiment(args.review/name)
        if name=='validation':
            verify_calibration(meta)
    verify_audits(args.review)
