"""Check results recorded in the simulation archive."""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def validate(folder):
    summary = json.loads((folder / 'summary.json').read_text())
    rows = pd.read_csv(folder / 'scenario_results.csv.gz')
    key = ['condition', 'network_id', 'scenario_id']
    assert not rows.duplicated(key + ['method']).any()
    assert rows.groupby(key).size().eq(5).all()
    target = ('true_risk_bps', 'lower_bps', 'upper_bps', 'indirect_events', 'direct_solvent')
    assert rows.groupby(key)[list(target)].nunique().eq(1).all().all()
    for column in ('true_risk_bps', 'estimated_risk_bps'):
        assert (rows[column] >= rows.lower_bps - 1e-5).all()
        assert (rows[column] <= rows.upper_bps + 1e-5).all()
    for cond, result in summary['conditions'].items():
        sub = rows[rows.condition == cond]
        assert sub.network_id.nunique() == result['networks']
        assert len(sub) == 5 * result['match_count']
        assert sub.groupby(['network_id', 'method']).size().eq(9).all()
        for method, metric in result['models'].items():
            group = sub[sub.method == method]
            err = group.estimated_risk_bps - group.true_risk_bps
            assert np.isclose(np.mean(np.abs(err)), metric['mae'], rtol=0, atol=1e-10)
            assert np.isclose(err.mean(), metric['bias'], rtol=0, atol=1e-10)
            assert np.isclose(np.quantile(abs(err), .9), metric['p90'], rtol=0, atol=1e-10)
            assert np.isclose((group.upper_bps - group.lower_bps).mean(), result['bracket_width'], atol=1e-10)
            if metric['margin_residual'] is not None:
                assert metric['margin_residual'] < 1.5e-8
            assert metric['solver_residual'] < 1e-9
    with np.load(folder / 'case.npz') as case:
        assert np.all(case['true_q'] >= case['lower'] - 1e-8)
        assert np.all(case['true_q'] <= case['upper'] + 1e-8)
        assert np.allclose(case['predicted'].sum(axis=0), case['true'].sum(axis=0), atol=1e-7)
        assert np.allclose(case['predicted'].sum(axis=1), case['true'].sum(axis=1), atol=1e-7)
        assert np.allclose(case['predicted'][case['observed'] > 0], case['observed'][case['observed'] > 0])
    print(f'Seed {summary["config"]["network_seed"]}: {len(rows):,} unique estimate rows verified across six conditions.')


def validate_extension(folder, run_folders):
    audit=pd.read_csv(folder/'bound_audit.csv')
    summary=json.loads((folder/'bound_audit.json').read_text())['all']
    assert len(audit)==summary['scenarios']==864
    assert not audit.duplicated(['banks','hidden_receivers','network_id','scenario_id']).any()
    assert audit.groupby(['banks','hidden_receivers','network_id']).size().eq(9).all()
    for lo,hi in [('lower','minimum_feasible'),('minimum_feasible','true_loss'),
                  ('true_loss','maximum_feasible'),('maximum_feasible','upper')]:
        assert (audit[lo]<=audit[hi]+1e-7).all(), (lo,hi)
    upper_gap=audit.upper-audit.maximum_feasible
    lower_gap=audit.minimum_feasible-audit.lower
    assert np.isclose(upper_gap.mean(),summary['mean_upper_slack_bp'],rtol=0,atol=1e-10)
    assert np.isclose(upper_gap.max(),summary['max_upper_slack_bp'],rtol=0,atol=1e-10)
    assert np.isclose(lower_gap.mean(),summary['mean_lower_slack_bp'],rtol=0,atol=1e-10)
    rows=pd.read_csv(folder/'extension_scenarios.csv.gz')
    ext=json.loads((folder/'reconstruction_extension.json').read_text())
    assert not ext['pilot']
    assert not rows.duplicated(['run','condition','network_id','scenario_id','method']).any()
    assert (rows.estimated_risk_bps>=rows.lower_bps-1e-5).all()
    assert (rows.estimated_risk_bps<=rows.upper_bps+1e-5).all()
    indexes=['condition','network_id','scenario_id']
    for path in run_folders:
        run=path.name
        baseline=pd.read_csv(path/'scenario_results.csv.gz').query('method == "GNN-RAS"')
        sparse=rows[rows.run.eq(run)&rows.method.eq('Reciprocal sparse')]
        other=sparse[sparse.condition.ne('Published calibration 50%')]
        pair=baseline.merge(other,on=indexes,suffixes=('_base','_new'),validate='one_to_one')
        assert len(pair)==len(baseline)==len(other)
        assert np.max(abs(pair.true_risk_bps_base-pair.true_risk_bps_new))<2e-8
        for cond,g in sparse.groupby('condition'):
            metric=ext[run]['scenarios'][cond]
            err=g.estimated_risk_bps-g.true_risk_bps
            assert np.isclose(np.mean(abs(err)),metric['mae'],rtol=0,atol=2e-8)
            assert np.isclose(err.mean(),metric['bias'],rtol=0,atol=2e-8)
            assert metric['margin_residual']<=1.5e-8
    cal=ext['results']['calibrated_benchmark']
    assert cal['networks']==96 and cal['banks']==65 and cal['match_count']==864
    assert round(cal['density_pct'],3)==5.505 and round(cal['observed_topology']['reciprocity_pct'],2)==7.86
    crows=rows[rows.condition.eq('Published calibration 50%')]
    assert len(crows)==6*cal['match_count']
    for method,g in crows.groupby('method'):
        assert np.isclose(abs(g.estimated_risk_bps-g.true_risk_bps).mean(),cal['models'][method]['mae'],atol=1e-10)
    print(f'Extension: {len(audit)} audited stresses and {len(rows):,} additional estimate rows verified.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('folders', nargs='*', type=Path, default=[Path('results'), Path('replication')])
    parser.add_argument('--extension',type=Path)
    args=parser.parse_args()
    for folder in args.folders:
        validate(folder)
    if args.extension:
        validate_extension(args.extension,args.folders)
