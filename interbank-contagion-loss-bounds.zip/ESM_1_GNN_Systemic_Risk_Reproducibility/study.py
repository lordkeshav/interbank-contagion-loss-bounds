"""Synthetic interbank disclosure benchmark. Set BLAS threads before imports."""

import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')

import argparse
import json
import platform
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.optimize import linprog
from scipy.special import expit
from scipy.sparse import coo_matrix, eye, hstack, vstack
from sklearn import __version__ as sklearn_version
from sklearn.metrics import average_precision_score


SEED = 60431
FIT_SEEDS = (241, 931, 1741)
COVERAGES = (.25, .50, .75)
SHOCK_TYPES = ('Single-bank', 'Sector', 'Common-factor')
METHODS = ('Observed only', 'Flat RAS', 'Pairwise RAS', 'No-message MLP', 'GNN-RAS')
MATCHED = 'Matched MLP'
MATCHED_WIDTHS = (60, 39)
EPS = 1e-12
TOL = 5e-9
CONFIG = {
    'network_seed': SEED, 'fit_seeds': FIT_SEEDS,
    'train': 480, 'validation': 120, 'test_modular': 180, 'test_core': 150, 'test_size': 120,
    'banks': 32, 'size_shift_banks': 48, 'coverage': COVERAGES, 'shocks_per_type': 3,
    'batch_size': 48, 'max_epochs': 70, 'patience': 12, 'lr': 0.0025, 'l2': 0.00015,
    'hidden_widths': (32, 24), 'embedding_dim': 12, 'bootstrap_draws': 2500,
    'bootstrap_seed': 56043, 'event_tolerance': 1e-8, 'margin_tolerance': TOL,
    'scaling_max_iterations': 300, 'clearing_max_iterations': 160,
    'upper_max_iterations': 100,
}


@dataclass
class Network:
    liabilities: np.ndarray
    asset: np.ndarray
    equity: np.ndarray
    outside: np.ndarray
    payable: np.ndarray
    sector: np.ndarray
    shock: np.ndarray
    order_uniform: np.ndarray


def make_network(n, rng, topology):
    sector = np.resize(np.arange(4), n)
    rng.shuffle(sector)
    size = np.exp(np.clip(rng.normal(0, .83, n), -1.8, 1.9))
    log_size = np.log(size)
    preferred = np.where(rng.random(n) < .46, sector, rng.integers(0, 4, n))
    match = preferred[:, None] == sector[None, :]
    home = sector[:, None] == sector[None, :]
    core = size >= np.quantile(size, .80)
    core_pair = core[:, None] & core[None, :]
    activity = rng.normal(0, .38, n)
    if topology == 'modular':
        log_odds = -2.38 + 1.88 * match + .32 * home + .28 * log_size[None, :] + activity[:, None]
        weight_effect = .83 * match + .20 * home + .27 * log_size[None, :]
    elif topology == 'core':
        log_odds = -2.85 + 1.58 * core[None, :] + 1.30 * core_pair + .28 * match + activity[:, None]
        weight_effect = 1.05 * core[None, :] + .36 * core_pair + .15 * match + .40 * log_size[None, :]
    else:
        raise ValueError(topology)
    links = rng.random((n, n)) < expit(log_odds)
    np.fill_diagonal(links, False)
    for i in range(n):
        if links[i].sum() < 2:
            candidates = np.flatnonzero(~links[i] & (np.arange(n) != i))
            probability = expit(log_odds[i, candidates])
            selected = rng.choice(candidates, size=2 - links[i].sum(), replace=False,
                                  p=probability / probability.sum())
            links[i, selected] = True
    value = np.exp(weight_effect + rng.normal(0, .83, (n, n))) * links
    ib_payable = size * rng.uniform(.23, .57, n)
    full = value * (ib_payable / value.sum(axis=1))[:, None]
    ib_receivable = full.sum(axis=0)
    asset = size + ib_payable
    equity = (asset + ib_receivable) * rng.uniform(.045, .115, n)
    payable = asset + ib_receivable - equity
    outside = payable - ib_payable

    scenarios = []
    for typ in SHOCK_TYPES:
        for _ in range(CONFIG['shocks_per_type']):
            if typ == 'Single-bank':
                h = rng.uniform(.01, .065, n)
                target = rng.choice(n, p=np.sqrt(size) / np.sqrt(size).sum())
                h[target] = rng.uniform(.24, .54)
            elif typ == 'Sector':
                h = rng.uniform(.015, .070, n)
                h += (sector == rng.integers(0, 4)) * rng.uniform(.07, .21)
            else:
                h = rng.uniform(.035, .145) + rng.normal(0, .038, n)
            scenarios.append(h.clip(0, .65))
    link_ids = np.flatnonzero(links.ravel())
    assert np.all(outside > 0)
    return Network(full, asset, equity, outside, payable, sector, np.array(scenarios), rng.permutation(link_ids))


def observe(net, coverage, mechanism):
    count = int(round(coverage * len(net.order_uniform)))
    if mechanism == 'Uniform':
        order = net.order_uniform
    else:
        order = np.flatnonzero(net.liabilities.ravel())
        order = order[np.argsort(-net.liabilities.ravel()[order], kind='stable')]
    observed = np.zeros_like(net.liabilities)
    observed.ravel()[order[:count]] = net.liabilities.ravel()[order[:count]]
    return observed


def features(nets, coverage, mechanism):
    observed = np.stack([observe(net, coverage, mechanism) for net in nets])
    full = np.stack([net.liabilities for net in nets])
    asset = np.stack([net.asset for net in nets])
    equity = np.stack([net.equity for net in nets])
    external = np.stack([net.outside for net in nets])
    payable = np.stack([net.payable for net in nets])
    sector = np.stack([net.sector for net in nets])
    h = np.stack([net.shock for net in nets])
    in_total = full.sum(axis=1)
    out_total = full.sum(axis=2)
    in_obs = observed.sum(axis=1)
    out_obs = observed.sum(axis=2)
    r = np.maximum(0, out_total - out_obs)
    c = np.maximum(0, in_total - in_obs)
    out_graph = observed / np.maximum(out_obs[..., None], EPS)
    in_graph = observed.swapaxes(1, 2) / np.maximum(in_obs[..., None], EPS)
    n = observed.shape[-1]
    allowed = (~np.eye(n, dtype=bool)[None] & (observed == 0)
               & (r[:, :, None] > EPS) & (c[:, None, :] > EPS))
    log_scale = np.log(asset / np.median(asset, axis=1, keepdims=True))
    x = np.stack([
        log_scale, 5 * equity / (asset + in_total), 2 * out_total / payable,
        2 * in_total / (asset + in_total), r / np.maximum(out_total, EPS),
        c / np.maximum(in_total, EPS), np.log1p((observed > 0).sum(axis=2)) / 3,
        np.log1p((observed > 0).sum(axis=1)) / 3,
    ], axis=-1)
    group = np.eye(4)[sector]
    x = np.concatenate((x, group), axis=-1)
    cos_out = out_graph / np.maximum(np.linalg.norm(out_graph, axis=-1, keepdims=True), EPS)
    cos_in = in_graph / np.maximum(np.linalg.norm(in_graph, axis=-1, keepdims=True), EPS)
    # Each pair statistic is computable from the disclosed network and node attributes.
    pair = np.stack([
        sector[:, :, None] == sector[:, None, :],
        np.abs(log_scale[:, :, None] - log_scale[:, None, :]),
        (observed.swapaxes(1, 2) > 0),
        cos_out @ cos_out.swapaxes(1, 2),
        cos_in @ cos_in.swapaxes(1, 2),
        (out_graph @ group) @ group.swapaxes(1, 2),
    ], axis=-1)
    return dict(observed=observed, full=full, x=x, pair=pair, allowed=allowed, r=r, c=c,
                out_graph=out_graph, in_graph=in_graph, hidden=full-observed, d=h*asset[:, None]-equity[:, None],
                payable=payable, external=external, coverage=coverage, sector=sector, h=h, asset=asset)


LEARN_KEYS = ('x', 'pair', 'allowed', 'c', 'r', 'out_graph', 'in_graph', 'hidden')


def train_views(nets):
    views = [features(nets, coverage, 'Uniform') for coverage in COVERAGES]
    return {key: np.concatenate([view[key] for view in views]) for key in LEARN_KEYS}


def take(data, idx):
    return {key: data[key][idx] for key in LEARN_KEYS}


def init_model(kind, seed):
    rng = np.random.default_rng(seed)
    params = {'w_pair': np.zeros(6)}
    if kind == 'Pairwise RAS':
        return params
    mult = 3 if kind == 'GNN-RAS' else 1
    dim1, dim2 = MATCHED_WIDTHS if kind == MATCHED else CONFIG['hidden_widths']
    dim3 = CONFIG['embedding_dim']
    for name, a, b in [('W1', 12 * mult, dim1), ('W2', dim1 * mult, dim2),
                       ('U', dim2, dim3), ('V', dim2, dim3)]:
        params[name] = rng.normal(0, np.sqrt(2 / (a+b)), (a, b))
    params['b1'] = np.zeros(dim1)
    params['b2'] = np.zeros(dim2)
    return params


def messages(x, batch, kind):
    if kind == 'GNN-RAS':
        return np.concatenate((x, batch['out_graph'] @ x, batch['in_graph'] @ x), axis=-1)
    return x


def neural_prior(params, batch, kind):
    logits = np.einsum('bijd,d->bij', batch['pair'], params['w_pair'])
    if kind == 'Pairwise RAS':
        return logits, ()
    f1 = messages(batch['x'], batch, kind)
    z1 = np.tanh(f1 @ params['W1'] + params['b1'])
    f2 = messages(z1, batch, kind)
    z2 = np.tanh(f2 @ params['W2'] + params['b2'])
    a = z2 @ params['U']
    b = z2 @ params['V']
    return logits + a @ b.swapaxes(-1, -2) / np.sqrt(a.shape[-1]), (f1, z1, f2, z2, a, b)


def loss_gradient(params, batch, kind, gradient=True):
    logits, cache = neural_prior(params, batch, kind)
    mask = batch['allowed']
    row = batch['r']
    hidden = batch['hidden']
    log_prior = logits + np.log(np.maximum(batch['c'], EPS))[:, None, :]
    log_prior = np.where(mask, log_prior, -1e6)
    anchored = log_prior - log_prior.max(axis=-1, keepdims=True)
    mass = np.exp(anchored) * mask
    log_z = np.log(np.maximum(mass.sum(axis=-1, keepdims=True), EPS))
    total = max(row.sum(), EPS)
    ce = -np.sum(hidden * (anchored - log_z)) / total
    if not gradient:
        return float(ce)
    g = ((mass / np.exp(log_z)) * row[..., None] - hidden) / total
    grads = {'w_pair': np.einsum('bijd,bij->d', batch['pair'], g)}
    if cache:
        f1, z1, f2, z2, a, b = cache
        g = g / np.sqrt(a.shape[-1])
        ga, gb = g @ b, g.swapaxes(-1, -2) @ a
        flat_z2 = z2.reshape(-1, z2.shape[-1])
        grads['U'] = flat_z2.T @ ga.reshape(-1, ga.shape[-1])
        grads['V'] = flat_z2.T @ gb.reshape(-1, gb.shape[-1])
        gz2 = (ga @ params['U'].T + gb @ params['V'].T) * (1 - z2 ** 2)
        grads['b2'] = gz2.sum(axis=(0, 1))
        grads['W2'] = f2.reshape(-1, f2.shape[-1]).T @ gz2.reshape(-1, gz2.shape[-1])
        gm = gz2 @ params['W2'].T
        if kind == 'GNN-RAS':
            direct, outward, inward = np.split(gm, 3, axis=-1)
            gm = (direct + batch['out_graph'].swapaxes(1, 2) @ outward
                  + batch['in_graph'].swapaxes(1, 2) @ inward)
        gz1 = gm * (1 - z1 ** 2)
        grads['b1'] = gz1.sum(axis=(0, 1))
        grads['W1'] = f1.reshape(-1, f1.shape[-1]).T @ gz1.reshape(-1, gz1.shape[-1])
    return float(ce), grads


def gradient_check(data, kinds=METHODS[2:]):
    max_abs = 0
    for kind in kinds:
        params = init_model(kind, 123)
        _, grad = loss_gradient(params, data, kind)
        rng = np.random.default_rng(333)
        for name, param in params.items():
            for _ in range(3):
                idx = np.unravel_index(rng.integers(param.size), param.shape)
                point = param[idx]
                shift = 1e-5
                param[idx] = point + shift
                upper = loss_gradient(params, data, kind, False)
                param[idx] = point - shift
                lower = loss_gradient(params, data, kind, False)
                param[idx] = point
                max_abs = max(max_abs, float(abs((upper-lower)/(2*shift)-grad[name][idx])))
    assert max_abs < 2e-8, max_abs
    return max_abs


def fit(kind, seed, data, val, config):
    params = init_model(kind, seed)
    m = {key: np.zeros_like(value) for key, value in params.items()}
    v = {key: np.zeros_like(value) for key, value in params.items()}
    best_ce = np.inf
    best, selected = None, 0
    history = []
    rng = np.random.default_rng(seed + 10003)
    b = config['batch_size']
    step = 0
    for epoch in range(1, config['max_epochs'] + 1):
        order = rng.permutation(len(data['r']))
        for start in range(0, len(order), b):
            step += 1
            _, grads = loss_gradient(params, take(data, order[start:start+b]), kind)
            for key, p in params.items():
                g = grads[key] + config['l2'] * p
                m[key] = .9 * m[key] + .1 * g
                v[key] = .999 * v[key] + .001 * g*g
                p -= config['lr'] * (m[key] / (1-.9**step)) / (np.sqrt(v[key] / (1-.999**step)) + 1e-8)
        vloss = loss_gradient(params, val, kind, False)
        history.append(float(vloss))
        if vloss < best_ce - 1e-6:
            best_ce = vloss
            selected = epoch
            best = {key: value.copy() for key, value in params.items()}
        if epoch - selected >= config['patience']:
            break
    print(f'{kind:16s} seed {seed:4d}: validation CE {best_ce:.5f} at {selected:2d}/{epoch:2d}', flush=True)
    return best, {'method': kind, 'seed': seed, 'selected_epoch': selected, 'best_ce': best_ce,
                  'validation_ce': history, 'parameters': int(sum(x.size for x in params.values()))}


def repair_margins(approx, allowed, row, col, cutoff=np.inf):
    """L1 projection fallback for slow/boundary scaling instances."""
    i, j = np.where(allowed)
    edge = np.arange(len(i))
    n, e = len(row), len(i)
    if not e:
        return approx
    eq = coo_matrix((np.ones(2*e), (np.r_[i, j+n], np.r_[edge, edge])), shape=(2*n, e)).tocsc()
    ident = eye(e, format='csc')
    scale = max(row.sum(), EPS)
    target = approx[i,j] / scale
    upper = None if np.isinf(cutoff) else cutoff/scale
    bounds = [(0, upper)]*e + [(0, None)]*e
    solution = linprog(np.r_[np.zeros(e), np.ones(e)], A_eq=hstack([eq, 0*eq], format='csc'),
                       b_eq=np.r_[row, col]/scale,
                       A_ub=vstack([hstack([ident, -ident]), hstack([-ident, -ident])], format='csc'),
                       b_ub=np.r_[target, -target], bounds=bounds, method='highs',
                       options={'primal_feasibility_tolerance': 1e-9})
    if not solution.success:
        raise RuntimeError(solution.message)
    fixed = np.zeros_like(approx)
    fixed[i, j] = np.maximum(0, solution.x[:e]) * scale
    return fixed


def scale_prior(logits, data, diagnostics=None):
    r, c, allowed = data['r'], data['c'], data['allowed']
    scale = np.maximum(r.sum(axis=1), EPS)
    x = np.exp(np.clip(logits, -25, 25)) * allowed
    cutoff = data.get('cutoff', np.full(len(r), np.inf))
    capped = np.isfinite(cutoff).any()
    if capped:
        finite = np.isfinite(cutoff[:, None, None]) & allowed
        box = np.where(finite, cutoff[:, None, None], 1.)
        box_correction = np.zeros_like(x)
    for k in range(CONFIG['scaling_max_iterations']):
        x *= (r / np.maximum(x.sum(axis=-1), EPS))[:, :, None]
        x *= (c / np.maximum(x.sum(axis=1), EPS))[:, None, :]
        if capped:
            # KL Dykstra corrections for the margin sets are row/column multipliers
            # absorbed by their next normalisation. Only the box correction is stored.
            candidate = x * np.exp(np.minimum(box_correction, 650.))
            clipped = finite & (candidate > box)
            box_correction = np.where(clipped, np.log(np.maximum(candidate/box, 1.)), 0.)
            x = np.where(clipped, box, candidate)
        if k % 5 == 4:
            row_error = np.max(abs(x.sum(axis=-1)-r), axis=1)/scale
            col_error = np.max(abs(x.sum(axis=1)-c), axis=1)/scale
            if np.max(np.maximum(row_error, col_error)) <= TOL:
                break
    row_error = np.max(abs(x.sum(axis=-1)-r), axis=1)/scale
    col_error = np.max(abs(x.sum(axis=1)-c), axis=1)/scale
    fallback = np.flatnonzero(np.maximum(row_error, col_error) > TOL)
    for i in fallback:
        x[i] = repair_margins(x[i], allowed[i], r[i], c[i], cutoff[i])
    rowerr = np.max(abs(x.sum(axis=-1)-r), axis=1)/scale
    colerr = np.max(abs(x.sum(axis=1)-c), axis=1)/scale
    assert np.max(np.maximum(rowerr, colerr)) <= 3*TOL
    assert not np.any(x[~allowed] != 0)
    if capped:
        assert np.max(x-cutoff[:, None, None]) <= max(scale)*3*TOL
    if diagnostics is not None:
        diagnostics['allocations'] = diagnostics.get('allocations', 0) + len(r)
        diagnostics['l1_fallbacks'] = diagnostics.get('l1_fallbacks', 0) + len(fallback)
    return x, float(max(rowerr.max(), colerr.max()))


def clearing(full, d, payable):
    """Shortfall fractions, pre-clipping score, weighted fixed point residual."""
    q = (d/payable[:, None]).clip(0, 1)
    for _ in range(CONFIG['clearing_max_iterations']):
        raw = (d + q @ full) / payable[:, None]
        update = raw.clip(0, 1)
        if np.max(abs(update-q)) <= 1e-12:
            q = update
            break
        q = update
    score = (d + q @ full) / payable[:, None]
    error = float(np.max(abs(score.clip(0, 1)-q)))
    assert error < 1e-9
    return q, score, error


def upper_envelope(data):
    """Descending row-capacity envelope for every feasible hidden matrix."""
    d, payable = data['d'], data['payable'][:, None]
    observed, c, r, allowed = data['observed'], data['c'], data['r'], data['allowed']
    q = np.ones_like(d)
    rows = np.arange(len(r))[:, None, None]
    cutoff = data.get('cutoff')
    for _ in range(CONFIG['upper_max_iterations']):
        order = np.argsort(-q, axis=-1, kind='stable')
        caps = r[rows, order][..., None] * allowed[rows, order, :]
        if cutoff is not None:
            caps = np.minimum(caps, cutoff[:, None, None, None])
        used = np.minimum(caps, np.maximum(0, c[:, None, None, :] - (np.cumsum(caps, axis=-2)-caps)))
        exposure = np.sum(used * np.take_along_axis(q, order, axis=-1)[..., None], axis=-2)
        update = ((d + q @ observed + exposure) / payable).clip(0, 1)
        delta = np.max(abs(update-q))
        assert np.max(update-q) < 1e-9
        q = update
        if delta < 1e-10:
            break
    return q


def amplification(q, direct, external):
    return ((q-direct)*external[:, None, :]).sum(axis=-1)*10000/external.sum(axis=1)[:, None]


def conservation_upper(data, lower):
    """Outside-loss cap using observed clearing and a contraction residual allowance."""
    p, b, r, observed = (data[key] for key in ('payable', 'external', 'r', 'observed'))
    dp = data['d'] / p[:, None]
    observed_row = observed.sum(axis=2)
    rho = (observed_row/p).max(axis=1)
    residual = ((data['d'] + lower@observed)/p[:, None]).clip(0,1) - lower
    allowance = (abs(residual)*p[:, None]).sum(axis=-1) / (1-rho[:, None])
    unpaid = ((b+r)[:, None]*lower - b[:, None]*dp.clip(0,1)).sum(axis=-1)
    return (unpaid + allowance + 1e-13*p.sum(axis=1)[:, None])*1e4/b.sum(axis=1)[:, None]


def clearing_checks(net):
    full = net.liabilities[None]
    payable = net.payable[None]
    # A three-bank hand calculation checks the creditor orientation and indirect default.
    toy = np.array([[[0., 40., 0.], [0., 0., 0.], [0., 0., 0.]]])
    q, _, _ = clearing(toy, np.array([[[30., -9., -10.]]]), np.array([[100., 100., 100.]]))
    assert np.allclose(q, [[[.30, .03, 0.]]])
    q, _, _ = clearing(full, -net.equity[None, None], payable)
    assert np.all(q == 0)
    original = net.asset[None, None]*net.shock[None] - net.equity[None, None]
    q, _, _ = clearing(full, original, payable)
    more, _, _ = clearing(full, original + .015*net.asset[None, None], payable)
    assert np.all(more >= q - 1e-11)


def intervals(delta, rng, count):
    draws = rng.integers(0, len(delta), (count, len(delta)))
    return np.quantile(np.mean(delta[draws], axis=1), [.025, .975]).tolist()


def evaluate(label, nets, coverage, mechanism, models, config, rng, case_path=None):
    dset = features(nets, coverage, mechanism)
    full, observed, d = (dset[name] for name in ('full', 'observed', 'd'))
    payable, external = dset['payable'], dset['external']
    direct = (d/payable[:, None]).clip(0, 1)
    true, _, resid = clearing(full, d, payable)
    true_risk = amplification(true, direct, external)
    lower, _, _ = clearing(observed, d, payable)
    up_chunks = []
    for start in range(0, len(nets), 32):
        stop = start+32
        up_chunks.append(upper_envelope({key:dset[key][start:stop] for key in
                        ('d','payable','observed','c','r','allowed')}))
    upper = np.concatenate(up_chunks)
    assert np.max(lower-true) < 1e-8 and np.max(true-upper) < 1e-8
    low_risk, up_risk = (amplification(q, direct, external) for q in (lower, upper))
    event = true > config['event_tolerance']
    candidate = d <= 0
    rows, records = {}, []
    for method in METHODS:
        if method == 'Observed only':
            fit_matrix = observed
            margin_residual = None
        else:
            if method == 'Flat RAS':
                logits = np.zeros_like(full)
            else:
                logits = np.mean([neural_prior(params, dset, method)[0] for params in models[method]], axis=0)
            allocation, margin_residual = scale_prior(logits, dset)
            fit_matrix = observed + allocation
        pred, risk_score, resid = clearing(fit_matrix, d, payable)
        assert np.max(lower-pred) < 2e-8 and np.max(pred-upper) < 2e-8
        estimate = amplification(pred, direct, external)
        err = estimate - true_risk
        risk_ap = average_precision_score(event[candidate], risk_score[candidate])
        reallocated = abs(fit_matrix-full).sum(axis=(1,2))/(2*np.maximum(dset['hidden'].sum(axis=(1,2)), EPS))
        rows[method] = dict(mae=float(np.mean(abs(err))), bias=float(err.mean()),
                            p90=float(np.quantile(abs(err), .90)), ap=float(risk_ap),
                            realloc_pct=None if method == 'Observed only' else float(100*reallocated.mean()),
                            margin_residual=margin_residual, solver_residual=resid,
                            rmse=float(np.sqrt(np.mean(err**2))),
                            shock_mae={typ:float(np.mean(abs(err[:, np.repeat(np.arange(3),CONFIG['shocks_per_type']) == k])))
                                       for k,typ in enumerate(SHOCK_TYPES)})
        if method == 'Flat RAS':
            reference = np.mean(abs(err), axis=-1)
        if method == 'GNN-RAS':
            diff = np.mean(abs(err), axis=-1) - reference
            rows[method]['delta_mae_ci'] = intervals(diff, rng, config['bootstrap_draws'])
            predicted_count = np.sum((pred > config['event_tolerance']) & candidate, axis=-1)
            true_count = np.sum(event & candidate, axis=-1)
            rows[method]['count_mae'] = float(np.mean(abs(predicted_count-true_count)))
            rows[method]['seed_mae'] = []
            for model in models[method]:
                seed_matrix = observed + scale_prior(neural_prior(model,dset,method)[0], dset)[0]
                q_seed, _, _ = clearing(seed_matrix, d, payable)
                rows[method]['seed_mae'].append(float(np.mean(abs(amplification(q_seed, direct, external)-true_risk))))
            if case_path:
                # Predeclared example: first ID test network and first sector scenario.
                m = CONFIG['shocks_per_type']
                np.savez_compressed(case_path, true=full[0], observed=observed[0], predicted=fit_matrix[0],
                                    true_q=true[0,m], predicted_q=pred[0,m], lower=lower[0,m], upper=upper[0,m],
                                    d=d[0,m], direct=direct[0,m], sector=dset['sector'][0],
                                    external=external[0], payable=payable[0],
                                    true_risk=true_risk[0,m], predicted_risk=estimate[0,m])
        for i in range(len(nets)):
            for j in range(d.shape[1]):
                records.append((label, i, j, SHOCK_TYPES[j//CONFIG['shocks_per_type']], method,
                                true_risk[i,j], estimate[i,j], low_risk[i,j], up_risk[i,j],
                                int(np.sum(event[i,j]&candidate[i,j])), int(np.sum(candidate[i,j])),
                                int(np.sum(d[i,j]>0))))
    density = (full>0).sum(axis=(1,2))/(full.shape[-1]*(full.shape[-1]-1))
    retained_mass = observed.sum(axis=(1,2))/full.sum(axis=(1,2))
    stats = dict(networks=len(nets), banks=full.shape[-1], match_count=len(nets)*d.shape[1],
                 coverage=coverage, mechanism=mechanism,
                 density_pct=float(100*density.mean()), visible_value_pct=float(100*retained_mass.mean()),
                 actual_risk_mean=float(true_risk.mean()), actual_risk_p90=float(np.quantile(true_risk,.9)),
                 bracket_width=float((up_risk-low_risk).mean()), bracket_width_p90=float(np.quantile(up_risk-low_risk,.9)),
                 mean_direct_count=float(np.mean(np.sum(d>0, axis=-1))),
                 mean_indirect_count=float(np.mean(np.sum(event&candidate, axis=-1))),
                 indirect_prevalence=float(event[candidate].mean()), max_rho=float((full.sum(axis=-1)/payable).max()),
                 models=rows)
    print(f'{label:22s} {len(nets):3d} networks | actual mean {true_risk.mean():.2f} bp | '
          f'Flat {rows["Flat RAS"]["mae"]:.3f} | GNN {rows["GNN-RAS"]["mae"]:.3f} | '
          f'width {(up_risk-low_risk).mean():.2f}', flush=True)
    return stats, records


def run(directory, pilot, network_seed):
    directory.mkdir(parents=True, exist_ok=True)
    config = CONFIG.copy()
    config['network_seed'] = network_seed
    if pilot:
        config.update(train=48, validation=16, test_modular=20, test_core=20, test_size=15,
                      max_epochs=12, bootstrap_draws=400)
    ss = np.random.SeedSequence(network_seed).spawn(5)
    attrs = [('train', config['banks'], 'modular'), ('validation', config['banks'], 'modular'),
             ('test_modular', config['banks'], 'modular'), ('test_core', config['banks'], 'core'),
             ('test_size', config['size_shift_banks'], 'modular')]
    sets = {}
    for seed, (key, n, topology) in zip(ss, attrs):
        sets[key] = [make_network(n, np.random.default_rng(r), topology) for r in seed.spawn(config[key])]
    train, val = (train_views(sets[name]) for name in ('train', 'validation'))
    grad_resid = gradient_check(take(train, slice(0,4)))
    clearing_checks(sets['train'][0])
    rng = np.random.default_rng(config['bootstrap_seed'])
    models, histories = {}, []
    for method in METHODS[2:]:
        seeds = FIT_SEEDS[:1] if pilot or method == 'Pairwise RAS' else FIT_SEEDS
        models[method] = []
        for seed in seeds:
            params, history = fit(method, seed, train, val, config)
            histories.append(history)
            models[method].append(params)
    np.savez_compressed(directory/'model_weights.npz', **{
        f'{name}_{i}_{key}': value for name, group in models.items()
        for i, params in enumerate(group) for key, value in params.items()
    })
    fitted = [
        ('Modular 25%', 'test_modular', .25, 'Uniform'), ('Modular 50%', 'test_modular', .50, 'Uniform'),
        ('Modular 75%', 'test_modular', .75, 'Uniform'), ('Large-first 50%', 'test_modular', .50, 'Large-first'),
        ('Core-periphery 50%', 'test_core', .50, 'Uniform'), ('48-bank 50%', 'test_size', .50, 'Uniform'),
    ]
    output = dict(config=config, pilot=pilot, gradient_check_max_abs=grad_resid,
                  runs=histories, conditions={}, versions={
                    'python': platform.python_version(), 'numpy':np.__version__, 'pandas':pd.__version__,
                    'scipy':scipy.__version__, 'scikit-learn':sklearn_version,
                  })
    records = []
    for label, key, coverage, mechanism in fitted:
        stat, detail = evaluate(label, sets[key], coverage, mechanism, models, config, rng,
                                directory/'case.npz' if label == 'Modular 50%' else None)
        output['conditions'][label] = stat
        records.extend(detail)
    columns = ('condition', 'network_id', 'scenario_id', 'shock', 'method', 'observed_risk_bps',
               'estimated_risk_bps', 'lower_bps', 'upper_bps', 'indirect_events', 'direct_solvent', 'direct_defaults')
    pd.DataFrame(records, columns=columns).rename(columns={'observed_risk_bps':'true_risk_bps'}).to_csv(
        directory/'scenario_results.csv.gz', index=False, compression={'method':'gzip','mtime':0})
    (directory/'summary.json').write_text(json.dumps(output, indent=2, allow_nan=False)+'\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=Path('results'))
    parser.add_argument('--pilot', action='store_true')
    parser.add_argument('--network-seed', type=int, default=SEED)
    args = parser.parse_args()
    start = time.monotonic()
    run(args.output, args.pilot, args.network_seed)
    print(f'Elapsed seconds: {time.monotonic()-start:.2f}', flush=True)
